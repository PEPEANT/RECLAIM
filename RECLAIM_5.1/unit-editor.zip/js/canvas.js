/**
 * CANVAS.JS
 * Canvas rendering logic for the unit editor
 */

const CanvasRenderer = {
    canvas: null,
    ctx: null,
    animationId: null,

    /**
     * Initialize the canvas
     * @param {HTMLCanvasElement} canvasElement - Canvas element
     */
    init(canvasElement) {
        this.canvas = canvasElement;
        this.ctx = canvasElement.getContext('2d');

        // Listen for state changes
        EditorState.on('unitChanged', () => this.draw());
        EditorState.on('unitUpdated', () => this.draw());
        EditorState.on('partUpdated', () => this.draw());
        EditorState.on('partAdded', () => this.draw());
        EditorState.on('partRemoved', () => this.draw());
        EditorState.on('unitReset', () => this.draw());
        EditorState.on('historyChanged', () => this.draw());
        EditorState.on('scaleChanged', () => this.draw());
        EditorState.on('xrayToggled', () => this.draw());
        EditorState.on('selectionChanged', () => this.draw());
    },

    /**
     * Apply line style to context
     * @param {string} style - Line style (solid, dash, dot)
     */
    applyLineStyle(style) {
        const scale = EditorState.scale;
        if (style === 'dash') {
            this.ctx.setLineDash([6 / scale, 4 / scale]);
        } else if (style === 'dot') {
            this.ctx.setLineDash([2 / scale, 4 / scale]);
        } else {
            this.ctx.setLineDash([]);
        }
    },

    /**
     * Get color value (handle 'team' color)
     * @param {string} color - Color value
     * @returns {string} Resolved color
     */
    getColor(color) {
        return color === 'team' ? EditorState.teamColor : color;
    },

    /**
     * Draw the entire canvas
     */
    draw() {
        const { ctx, canvas } = this;
        if (!ctx || !canvas) return;

        const { unitData, scale, xrayMode, showGrid, showHandles } = EditorState;

        // Clear canvas
        ctx.fillStyle = CANVAS_CONFIG.backgroundColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw grid
        if (showGrid) {
            this.drawGrid();
        }

        // If no unit data, stop here
        if (!unitData || !unitData.parts) return;

        // Save context and transform (apply view offset for panning)
        ctx.save();
        ctx.translate(
            canvas.width / 2 + EditorState.viewOffsetX,
            canvas.height / 2 + EditorState.viewOffsetY
        );
        ctx.scale(scale, scale);

        // Draw all parts
        const parts = Object.entries(unitData.parts);

        // Sort by zIndex if available
        parts.sort((a, b) => {
            const zA = a[1].zIndex || 0;
            const zB = b[1].zIndex || 0;
            return zA - zB;
        });

        for (const [name, part] of parts) {
            this.drawPart(name, part, xrayMode);
        }

        // Draw handles if enabled
        if (showHandles) {
            for (const [name, part] of parts) {
                this.drawHandles(name, part);
            }
        }

        // Draw transform gizmo (bounding box with handles)
        this.drawTransformGizmo();

        // Draw box selection rectangle
        this.drawBoxSelection();

        ctx.restore();
    },

    /**
     * Draw transform gizmo for selected parts
     */
    drawTransformGizmo() {
        const bounds = EditorState.getSelectionBounds();
        if (!bounds || bounds.width < 1 || bounds.height < 1) return;

        const { ctx } = this;
        const scale = EditorState.scale;
        const handleSize = 6 / scale;
        const rotateOffset = 25 / scale;

        // Draw bounding box
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 1 / scale;
        ctx.setLineDash([4 / scale, 4 / scale]);
        ctx.strokeRect(bounds.x, bounds.y, bounds.width, bounds.height);
        ctx.setLineDash([]);

        // Draw corner handles
        const corners = [
            { x: bounds.x, y: bounds.y },
            { x: bounds.x + bounds.width, y: bounds.y },
            { x: bounds.x + bounds.width, y: bounds.y + bounds.height },
            { x: bounds.x, y: bounds.y + bounds.height }
        ];

        corners.forEach(corner => {
            ctx.fillStyle = '#fff';
            ctx.strokeStyle = '#3b82f6';
            ctx.lineWidth = 1.5 / scale;
            ctx.beginPath();
            ctx.rect(corner.x - handleSize / 2, corner.y - handleSize / 2, handleSize, handleSize);
            ctx.fill();
            ctx.stroke();
        });

        // Draw edge handles
        const edges = [
            { x: bounds.cx, y: bounds.y },
            { x: bounds.x + bounds.width, y: bounds.cy },
            { x: bounds.cx, y: bounds.y + bounds.height },
            { x: bounds.x, y: bounds.cy }
        ];

        edges.forEach(edge => {
            ctx.fillStyle = '#fff';
            ctx.strokeStyle = '#3b82f6';
            ctx.lineWidth = 1.5 / scale;
            ctx.beginPath();
            ctx.rect(edge.x - handleSize / 2, edge.y - handleSize / 2, handleSize, handleSize);
            ctx.fill();
            ctx.stroke();
        });

        // Draw rotation handle (circle above top center)
        const rotateX = bounds.cx;
        const rotateY = bounds.y - rotateOffset;

        // Line from bbox top to rotation handle
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 1 / scale;
        ctx.beginPath();
        ctx.moveTo(bounds.cx, bounds.y);
        ctx.lineTo(rotateX, rotateY);
        ctx.stroke();

        // Rotation handle circle
        ctx.fillStyle = '#fff';
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 1.5 / scale;
        ctx.beginPath();
        ctx.arc(rotateX, rotateY, handleSize / 1.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Draw rotation icon inside handle
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 1 / scale;
        ctx.beginPath();
        ctx.arc(rotateX, rotateY, handleSize / 3, -Math.PI / 4, Math.PI);
        ctx.stroke();
    },

    /**
     * Draw box selection rectangle
     */
    drawBoxSelection() {
        const box = EditorState.boxSelect;
        if (!box) return;

        const { ctx } = this;
        const scale = EditorState.scale;

        const x = Math.min(box.x1, box.x2);
        const y = Math.min(box.y1, box.y2);
        const w = Math.abs(box.x2 - box.x1);
        const h = Math.abs(box.y2 - box.y1);

        // Fill
        ctx.fillStyle = 'rgba(59, 130, 246, 0.1)';
        ctx.fillRect(x, y, w, h);

        // Stroke
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 1 / scale;
        ctx.setLineDash([4 / scale, 2 / scale]);
        ctx.strokeRect(x, y, w, h);
        ctx.setLineDash([]);
    },

    /**
     * Draw the grid
     */
    drawGrid() {
        const { ctx, canvas } = this;
        const gridSize = CANVAS_CONFIG.gridSize;

        ctx.strokeStyle = CANVAS_CONFIG.gridColor;
        ctx.lineWidth = 0.5;

        // Vertical lines
        for (let x = 0; x < canvas.width; x += gridSize) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, canvas.height);
            ctx.stroke();
        }

        // Horizontal lines
        for (let y = 0; y < canvas.height; y += gridSize) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
        }
    },

    /**
     * Draw a single part
     * @param {string} name - Part name
     * @param {Object} part - Part data
     * @param {boolean} xrayMode - X-Ray mode enabled
     */
    drawPart(name, part, xrayMode) {
        const { ctx } = this;
        const color = this.getColor(part.color);
        const scale = EditorState.scale;

        switch (part.type) {
            case 'rect':
                ctx.fillStyle = xrayMode ? 'rgba(100,100,100,0.3)' : color;
                ctx.fillRect(part.x, part.y, part.w, part.h);
                if (xrayMode) {
                    ctx.strokeStyle = '#60a5fa';
                    ctx.lineWidth = 1 / scale;
                    ctx.strokeRect(part.x, part.y, part.w, part.h);
                }
                break;

            case 'circle':
                ctx.fillStyle = xrayMode ? 'rgba(100,100,100,0.3)' : color;
                ctx.beginPath();
                ctx.arc(part.x, part.y, part.r, 0, Math.PI * 2);
                ctx.fill();
                if (xrayMode) {
                    ctx.strokeStyle = '#60a5fa';
                    ctx.lineWidth = 1 / scale;
                    ctx.stroke();
                }
                break;

            case 'arc':
                ctx.fillStyle = xrayMode ? 'rgba(100,100,100,0.3)' : color;
                ctx.beginPath();
                ctx.arc(part.x, part.y, part.r, Math.PI, 0);
                ctx.fill();
                if (xrayMode) {
                    ctx.strokeStyle = '#60a5fa';
                    ctx.lineWidth = 1 / scale;
                    ctx.stroke();
                }
                break;

            case 'polygon':
                if (!part.points || part.points.length < 3) break;
                ctx.fillStyle = xrayMode ? 'rgba(100,100,100,0.3)' : color;
                ctx.beginPath();
                part.points.forEach((p, i) => {
                    if (i === 0) ctx.moveTo(p.x, p.y);
                    else ctx.lineTo(p.x, p.y);
                });
                ctx.closePath();
                ctx.fill();
                if (color === EditorState.teamColor || xrayMode) {
                    ctx.strokeStyle = xrayMode ? '#60a5fa' : 'rgba(0,0,0,0.2)';
                    ctx.lineWidth = 1 / scale;
                    ctx.stroke();
                }
                break;

            case 'line':
                if (!part.points || part.points.length < 2) break;
                ctx.strokeStyle = color || '#94a3b8';
                ctx.lineWidth = (part.width || 2) / scale;
                this.applyLineStyle(part.lineStyle);
                ctx.beginPath();
                part.points.forEach((p, i) => {
                    if (i === 0) ctx.moveTo(p.x, p.y);
                    else ctx.lineTo(p.x, p.y);
                });
                ctx.stroke();
                ctx.setLineDash([]);
                break;

            case 'wheels':
                if (!part.points) break;
                part.points.forEach(w => {
                    // Outer wheel
                    ctx.fillStyle = '#0f172a';
                    ctx.beginPath();
                    ctx.arc(w.x, w.y, 6.5, 0, Math.PI * 2);
                    ctx.fill();
                    // Middle
                    ctx.fillStyle = '#475569';
                    ctx.beginPath();
                    ctx.arc(w.x, w.y, 3.5, 0, Math.PI * 2);
                    ctx.fill();
                    // Center
                    ctx.fillStyle = '#000';
                    ctx.beginPath();
                    ctx.arc(w.x, w.y, 1, 0, Math.PI * 2);
                    ctx.fill();
                });
                break;

            case 'group':
                if (name === 'turret') {
                    ctx.save();
                    ctx.translate(part.x, part.y);
                    ctx.fillStyle = '#020617';
                    ctx.fillRect(-10, -5, 20, 10);
                    ctx.fillStyle = '#000';
                    ctx.fillRect(10, -2, 16, 4);
                    ctx.fillStyle = '#334155';
                    ctx.fillRect(-5, -4, 10, 2);
                    ctx.restore();
                }
                break;

            case 'rotor':
                ctx.save();
                ctx.translate(part.x, part.y);
                ctx.rotate(EditorState.rotorAngle * 3);
                ctx.fillStyle = '#000';
                ctx.fillRect(-part.w / 2, -part.h / 2, part.w, part.h);
                ctx.restore();
                break;
        }
    },

    /**
     * Draw handles for a part
     * @param {string} name - Part name
     * @param {Object} part - Part data
     */
    drawHandles(name, part) {
        const { ctx } = this;
        const scale = EditorState.scale;
        const isSelected = EditorState.selectedPart === name;
        const handleRadius = CANVAS_CONFIG.handleRadius / scale;

        // Get handle color based on type
        const handleColor = HANDLE_COLORS[part.type] || '#60a5fa';

        // Draw handles based on part type
        if (part.type === 'polygon' || part.type === 'wheels' || part.type === 'line') {
            if (!part.points) return;
            part.points.forEach((p, i) => {
                ctx.fillStyle = isSelected ? '#fff' : handleColor;
                ctx.beginPath();
                ctx.arc(p.x, p.y, handleRadius, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#fff';
                ctx.lineWidth = 1 / scale;
                ctx.stroke();
            });
        } else if (part.type === 'rect' || part.type === 'rotor') {
            ctx.fillStyle = isSelected ? '#fff' : handleColor;
            ctx.beginPath();
            ctx.arc(part.x, part.y, handleRadius, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 1 / scale;
            ctx.stroke();
        } else if (part.type === 'circle' || part.type === 'arc') {
            ctx.fillStyle = isSelected ? '#fff' : handleColor;
            ctx.beginPath();
            ctx.arc(part.x, part.y, handleRadius, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 1 / scale;
            ctx.stroke();
        } else if (part.type === 'group') {
            ctx.fillStyle = isSelected ? '#fff' : handleColor;
            ctx.beginPath();
            ctx.arc(part.x, part.y, handleRadius, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 1 / scale;
            ctx.stroke();
        }
    },

    /**
     * Start animation loop
     */
    startAnimation() {
        const animate = () => {
            EditorState.rotorAngle += 0.1;
            this.draw();
            this.animationId = requestAnimationFrame(animate);
        };
        animate();
    },

    /**
     * Stop animation loop
     */
    stopAnimation() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
    }
};

// Export for use in other modules
if (typeof window !== 'undefined') {
    window.CanvasRenderer = CanvasRenderer;
}
