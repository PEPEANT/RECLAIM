﻿// [RULE] 인게임 안내/상태/채팅 메시지는 UI 토스트 금지. ChatPanel.push()로만 출력.
const LOGICAL_HEIGHT = 720;

// [P0-1] In-place array compaction (zero allocation)
function compactArray(arr, keepFn) {
    let w = 0;
    for (let i = 0; i < arr.length; i++) {
        if (keepFn(arr[i])) arr[w++] = arr[i];
    }
    arr.length = w;
}

const game = {
    canvas: document.getElementById('game-canvas'),
    ctx: null, width: 0, height: 0, groundY: 0,
    frame: 0, running: false, cameraX: 0,
    minimapInterval: 8,
    cameraLockActive: false,
    cameraLockTarget: null,

    // [VFX] Screen Shake / Flash (screen-space)
    shake: 0,
    shakeDecay: 0.90,
    flash: 0,
    flashDecay: 0.85,

    addShake(amount) {
        // amount: 대략 0~30
        const a = Math.max(0, Number(amount) || 0);
        this.shake = Math.max(this.shake || 0, a);
    },

    addFlash(amount) {
        // amount: 0~1
        const a = Math.max(0, Math.min(1, Number(amount) || 0));
        this.flash = Math.max(this.flash || 0, a);
    },

    scaleRatio: 1,
    logicalWidth: 1280, // Note: This might be less relevant if we calc width dynamically, but keeping for legacy refs or init
    logicalHeight: LOGICAL_HEIGHT,

    // [NEW] Total War Trigger Flag
    totalWarTriggered: false,

    // [NEW] 프리게임 커스텀 옵션
    settings: {
        includeForwardDefense: false,
    },
    mapOrder: ['city', 'plain', 'mountain', 'village'],
    clearedMaps: [],
    firstRunDone: false,
    devUnlockAllMaps: false,
    _devPPressCount: 0,
    _devLastPPressAt: 0,

    players: [], enemies: [], civilians: [], projectiles: [], particles: [], buildings: [],
    particleCap: 300,
    particleSpawnCap: 60,
    particleCullPadding: 200,
    _particleSpawnFrame: -1,
    _particleSpawnCount: 0,
    supply: CONFIG.startSupply, enemySupply: CONFIG.startSupply,
    cooldowns: {}, playerStock: {}, enemyStock: {}, enemyCooldowns: {},
    skillCharges: { emp: 5, nuke: 1, tactical: 5 },
    empTimer: 0, targetingType: null, killCount: 0,
    playerBuildings: [], enemyBuildings: [],
    selectedBuilding: null,
    enemyEverSeen: false,
    playerEverSeen: false,
    civilianDeaths: 0,
    airRaidTriggered: false,
    airRaidBomberTimeout: null,
    civilianEvacActive: false,
    civilianEvacX: null,
    cityArmorNewsShown: false,
    cityMidNewsShown: false,
    cityTotalWarNewsShown: false,

    // ============================================
    // [NEW] 건설 모드 상태
    // ============================================
    buildMode: {
        active: false,
        type: null,           // 건설할 건물 타입 (watchtower)
        previewX: 0,          // 프리뷰 위치 (월드 좌표)
        previewY: 0,
        valid: false,         // 배치 가능 여부
        worker: null,         // 건설 중인 작업자 참조
    },
    builderCooldown: 0,       // 작업자 공용 쿨타임
    watchtowerBuilt: false,   // [3.8] 감시탑 1회 건설 제한 플래그

    // [Queue System]
    spawnQueue: {},
    holdTimer: null, holdKey: null,

    // [Category & Spawn]
    currentCategory: 'infantry',

    getSelectedOperators() {
        if (!this.selectedUnits || this.selectedUnits.size === 0) return [];
        return Array.from(this.selectedUnits).filter(u =>
            u && !u.dead && u.stats?.operator === true
        );
    },

    getSelectedDrones() {
        if (!this.selectedUnits || this.selectedUnits.size === 0) return [];
        return Array.from(this.selectedUnits).filter(u => {
            if (!u || u.dead || !u.stats) return false;
            if (u.stats.operator) return false;
            if (u.stats.category === 'drone') return true;
            return (typeof u.stats.id === 'string' && u.stats.id.includes('drone'));
        });
    },

    getDeployableOperators() {
        return this.getSelectedOperators().filter(u =>
            u.droneChargesLeft > 0 && (!u.ownedDrone || u.ownedDrone.dead)
        );
    },

    spawnDroneForOperator(op, droneKey) {
        if (!op || op.dead || op.stats?.operator !== true) return null;
        if (op.droneChargesLeft <= 0 || op.ownedDrone) return null;

        const forwardOffset = 24;
        const facing = (op.facing != null) ? op.facing : ((op.team === 'player') ? 1 : -1);
        const spawnX = op.x + facing * forwardOffset;
        const spawnY = this.groundY;

        const drone = this.spawnUnitDirect(droneKey, spawnX, spawnY, op.team || 'player', true);
        if (!drone) return null;

        drone.ownerRef = op;
        drone.recallRequested = false;
        drone.recallTarget = null;
        drone.recallPhase = null;
        drone.holdFrames = 60;
        drone.launchTargetY = this.groundY - 110;

        op.opState = 'laptop';
        op.ownedDrone = drone;
        op.droneChargesLeft = Math.max(0, (op.droneChargesLeft || 0) - 1);
        op.manualDeployRequested = false;
        op.manualDeployType = null;
        return drone;
    },

    getSelectedDroneForRecall() {
        if (!this.selectedUnits || this.selectedUnits.size !== 1) return null;
        const u = this.selectedUnits.values().next().value;
        if (!u || u.dead) return null;
        if (u.stats?.id === 'drone_operator' && u.ownedDrone && !u.ownedDrone.dead) {
            if (!u.ownedDrone.ownerRef) u.ownedDrone.ownerRef = u;
            return u.ownedDrone;
        }
        const isDrone = (u.stats?.id === 'drone_suicide' || u.stats?.id === 'drone_at' || u.stats?.category === 'drone');
        if (!isDrone) return null;
        if (!u.ownerRef) {
            const owner = (this.players || []).find(p => p && p.stats?.operator && p.ownedDrone === u);
            if (owner) u.ownerRef = owner;
        }
        if (!u.ownerRef || u.ownerRef.dead) return null;
        return u;
    },

    requestDroneRecall(drone) {
        if (!drone || drone.dead) return false;

        // [P0-4] owner 재탐색 우선순위:
        // 1. 기존 ownerRef
        // 2. ownedDrone이 이 드론인 operator
        // 3. 가장 가까운 사용 가능한 operator (강제 재결속)
        let owner = drone.ownerRef;

        // 1차: 기존 ownerRef 확인
        if (!owner || owner.dead) {
            owner = (this.players || []).find(p => p && !p.dead && p.stats?.operator && p.ownedDrone === drone);
            if (owner) drone.ownerRef = owner;
        }

        // 2차: 그래도 없으면 가장 가까운 operator를 강제 결속
        if (!owner || owner.dead) {
            const availableOps = (this.players || []).filter(p =>
                p && !p.dead && p.stats?.operator && (!p.ownedDrone || p.ownedDrone.dead)
            );
            if (availableOps.length > 0) {
                // 가장 가까운 operator 찾기
                let nearest = availableOps[0];
                let minDist = Math.abs(drone.x - nearest.x);
                for (let i = 1; i < availableOps.length; i++) {
                    const dist = Math.abs(drone.x - availableOps[i].x);
                    if (dist < minDist) {
                        minDist = dist;
                        nearest = availableOps[i];
                    }
                }
                owner = nearest;
                drone.ownerRef = owner;
                owner.ownedDrone = drone;
                if (typeof ChatPanel !== 'undefined') {
                    ChatPanel.push('[복귀] 드론병 재연결됨', 'INFO');
                }
            }
        }

        // owner 결속 동기화
        if (owner && !owner.dead && owner.ownedDrone !== drone) {
            owner.ownedDrone = drone;
        }

        const wasRequested = !!drone.recallRequested;
        drone.recallRequested = true;
        drone.recallTarget = owner || drone.recallTarget || null;
        drone.recallPhase = 'approach';
        drone.commandState = 'recall';
        drone.commandMode = 'move';
        drone.commandTargetX = null;
        drone.commandTargetY = null;
        drone.targetX = null;
        drone.targetY = null;
        drone.lockedTarget = null;
        drone.attackTarget = null;
        drone.swarmTarget = null;
        drone.holdFrames = 0;
        drone.launchInit = false;

        if (!wasRequested && typeof ChatPanel !== 'undefined') {
            ChatPanel.push('[복귀] 드론 회수 중', 'ACTION');
        }
        return true;
    },

    requestRecallFromSelection() {
        if (!this.selectedUnits || this.selectedUnits.size === 0) return 0;
        let recalled = 0;
        this.selectedUnits.forEach(u => {
            if (!u || u.dead || !u.stats) return;
            if (u.stats.operator && u.ownedDrone && !u.ownedDrone.dead) {
                if (!u.ownedDrone.ownerRef) u.ownedDrone.ownerRef = u;
                if (this.requestDroneRecall(u.ownedDrone)) recalled++;
                return;
            }

            const isDrone = (u.stats.category === 'drone' || (u.stats.id && u.stats.id.includes('drone')));
            if (!isDrone || u.stats.operator) return;
            if (!u.ownerRef) {
                const owner = (this.players || []).find(p => p && p.stats?.operator && p.ownedDrone === u);
                if (owner) u.ownerRef = owner;
            }
            if (this.requestDroneRecall(u)) recalled++;
        });
        return recalled;
    },

    getEnemyAt(wx, wy, radius = 32) {
        const maxDist = Math.max(6, radius);
        let best = null;
        let bestDist = maxDist;

        const consider = (t, tx, ty) => {
            const dx = tx - wx;
            const dy = ty - wy;
            const dist = Math.hypot(dx, dy);
            if (dist <= bestDist) {
                bestDist = dist;
                best = t;
                if (bestDist <= 1) return true;
            }
            return false;
        };

        const enemies = this.enemies || [];
        for (let i = 0; i < enemies.length; i++) {
            const e = enemies[i];
            if (!e || e.dead) continue;
            const tx = e.x;
            const ty = e.y - (e.height || 20) * 0.5;
            if (consider(e, tx, ty)) return best;
        }

        const buildings = this.enemyBuildings || [];
        for (let i = 0; i < buildings.length; i++) {
            const b = buildings[i];
            if (!b || b.dead) continue;
            const halfW = (b.width || 40) * 0.5;
            const left = b.x - halfW;
            const right = b.x + halfW;
            const top = b.y - (b.height || 40);
            const bottom = b.y;
            const dx = (wx < left) ? (left - wx) : (wx > right ? (wx - right) : 0);
            const dy = (wy < top) ? (top - wy) : (wy > bottom ? (wy - bottom) : 0);
            const dist = Math.hypot(dx, dy);
            if (dist <= bestDist) {
                bestDist = dist;
                best = b;
                if (bestDist <= 1) return best;
            }
        }

        return best;
    },

    assignDroneLocks(target) {
        if (!target || target.dead) return false;
        const drones = this.getSelectedDrones();
        if (drones.length === 0) return false;

        let chosen = drones.find(d => !d.lockedTarget || d.lockedTarget.dead);
        if (!chosen) {
            const idx = (this.droneLockCursor || 0) % drones.length;
            chosen = drones[idx];
        }
        if (!chosen) return false;

        chosen.lockedTarget = target;
        chosen.recallRequested = false;
        chosen.recallPhase = null;
        chosen.recallTarget = null;
        chosen.swarmTarget = null;
        chosen.attackTarget = null;
        chosen.holdFrames = 0;
        chosen.launchInit = false;

        this.droneLockCursor = (this.droneLockCursor || 0) + 1;

        if (typeof ChatPanel !== 'undefined') {
            ChatPanel.push('[락다운] 드론 1기 -> 타겟 지정', 'ACTION');
        }
        return true;
    },

    tryDroneLockdown(wx, wy) {
        const drones = this.getSelectedDrones();
        if (drones.length === 0) return false;
        const enemy = this.getEnemyAt(wx, wy);
        if (!enemy) return false;
        return this.assignDroneLocks(enemy);
    },

    // Toast Wrapper
    showToast(msg) { ui.showToast(msg); },

    /**
     * [NEW] Update HUD selection display
     * Called from all selection change points (single entry point)
     */
    updateHUDSelection() {
        if (typeof HUD === 'undefined') return;

        // Priority: selectedUnits > selectedBuilding > null
        if (this.selectedUnits && this.selectedUnits.size > 0) {
            if (this.selectedUnits.size === 1) {
                // Single unit selected
                const u = this.selectedUnits.values().next().value;
                if (u && !u.dead) {
                    HUD.setSelection({
                        kind: 'unit',
                        name: u.stats?.name || 'Unit',
                        hp: u.hp || 0,
                        hpMax: u.stats?.hp || 100,
                        color: u.stats?.color || '#60a5fa'
                    });
                    return;
                }
            } else {
                // Multiple units selected
                HUD.setSelection({
                    kind: 'multi',
                    count: this.selectedUnits.size
                });
                return;
            }
        }

        if (this.selectedBuilding && !this.selectedBuilding.dead) {
            const b = this.selectedBuilding;
            HUD.setSelection({
                kind: 'building',
                name: b.name || b.type || 'Building',
                buildingType: b.type,  // [NEW] 건물 타입 (bunker, hq_player 등)
                building: b,           // [NEW] 건물 객체 참조 (주둔 보병 정보용)
                hp: b.hp || 0,
                hpMax: b.maxHp || 100,
                team: b.team || 'neutral'
            });
            return;
        }

        // Nothing selected
        HUD.setSelection(null);
    },

    // [PATCH] Apply unit/map overrides from localStorage (editor)
    applyLocalPatch() {
        let raw = null;
        try {
            raw = localStorage.getItem('reclaim_unit_patch_v1');
        } catch (_) {
            return;
        }
        if (!raw) return;

        let patch = null;
        try {
            patch = JSON.parse(raw);
        } catch (_) {
            return;
        }
        if (!patch || typeof patch !== 'object') return;

        const unitsPatch = (patch.units && typeof patch.units === 'object') ? patch.units : null;
        if (unitsPatch && typeof CONFIG !== 'undefined' && CONFIG.units) {
            Object.keys(unitsPatch).forEach((unitKey) => {
                const unit = CONFIG.units[unitKey];
                const fields = unitsPatch[unitKey];
                if (!unit || typeof unit !== 'object' || !fields || typeof fields !== 'object') return;

                Object.keys(fields).forEach((field) => {
                    if (!Object.prototype.hasOwnProperty.call(unit, field)) return;
                    const val = fields[field];
                    if (typeof val === 'number') {
                        if (!Number.isFinite(val)) return;
                        unit[field] = val;
                    } else if (typeof val === 'string' || typeof val === 'boolean') {
                        unit[field] = val;
                    }
                });
            });
        }

        const mapsPatch = (patch.maps && typeof patch.maps === 'object') ? patch.maps : null;
        if (mapsPatch && typeof Maps !== 'undefined' && Maps.types) {
            Object.keys(mapsPatch).forEach((mapKey) => {
                const map = Maps.types[mapKey];
                const fields = mapsPatch[mapKey];
                if (!map || typeof map !== 'object' || !fields || typeof fields !== 'object') return;

                Object.keys(fields).forEach((field) => {
                    if (!Object.prototype.hasOwnProperty.call(map, field)) return;
                    const val = fields[field];
                    if (typeof val === 'number') {
                        if (!Number.isFinite(val)) return;
                        map[field] = val;
                    } else if (typeof val === 'string' || typeof val === 'boolean') {
                        map[field] = val;
                    }
                });
            });
        }

        if (typeof window !== 'undefined') {
            let skinsRaw = null;
            try {
                skinsRaw = localStorage.getItem('reclaim_skins_v1');
            } catch (_) { }

            const sanitizedSkins = {};
            if (skinsRaw && typeof CONFIG !== 'undefined' && CONFIG.units) {
                try {
                    const parsed = JSON.parse(skinsRaw);
                    if (parsed && typeof parsed === 'object') {
                        Object.keys(parsed).forEach((unitKey) => {
                            if (!CONFIG.units[unitKey]) return;
                            const skin = parsed[unitKey];
                            if (!skin || typeof skin !== 'object') return;

                            const clean = {};
                            const scale = Number(skin.scale);
                            if (Number.isFinite(scale)) clean.scale = scale;

                            if (skin.anchor && typeof skin.anchor === 'object') {
                                const ax = Number(skin.anchor.x);
                                const ay = Number(skin.anchor.y);
                                if (Number.isFinite(ax) || Number.isFinite(ay)) {
                                    clean.anchor = {
                                        x: Number.isFinite(ax) ? ax : 0,
                                        y: Number.isFinite(ay) ? ay : 0
                                    };
                                }
                            }

                            if (Array.isArray(skin.layers)) {
                                const layers = [];
                                skin.layers.forEach((layer) => {
                                    if (!layer || typeof layer !== 'object') return;
                                    const name = (typeof layer.name === 'string' && layer.name.trim()) ? layer.name.trim() : 'Layer';
                                    const color = (typeof layer.color === 'string' && layer.color.trim()) ? layer.color.trim() : '#38bdf8';
                                    const curve = (typeof layer.curve === 'string' && layer.curve.trim()) ? layer.curve.trim() : null;
                                    const shape = (typeof layer.shape === 'string' && layer.shape.trim()) ? layer.shape.trim() : null;
                                    const points = [];
                                    if (Array.isArray(layer.points)) {
                                        layer.points.forEach((pt) => {
                                            if (!pt || typeof pt !== 'object') return;
                                            const x = Number(pt.x);
                                            const y = Number(pt.y);
                                            if (!Number.isFinite(x) || !Number.isFinite(y)) return;
                                            points.push({ x, y });
                                        });
                                    }

                                    let cleanLayer = null;
                                    if (shape === 'circle') {
                                        const cx = Number(layer.cx);
                                        const cy = Number(layer.cy);
                                        const r = Number(layer.r);
                                        if (Number.isFinite(cx) && Number.isFinite(cy) && Number.isFinite(r) && r > 0) {
                                            cleanLayer = { name, color, shape: 'circle', cx, cy, r };
                                        }
                                    } else if (shape === 'arc') {
                                        const cx = Number(layer.cx);
                                        const cy = Number(layer.cy);
                                        const r = Number(layer.r);
                                        const start = Number(layer.start);
                                        const end = Number(layer.end);
                                        if (Number.isFinite(cx) && Number.isFinite(cy) && Number.isFinite(r) && r > 0 &&
                                            Number.isFinite(start) && Number.isFinite(end)) {
                                            cleanLayer = {
                                                name,
                                                color,
                                                shape: 'arc',
                                                cx,
                                                cy,
                                                r,
                                                start,
                                                end
                                            };
                                            if (layer.ccw === true) cleanLayer.ccw = true;
                                            if (layer.closed === false) cleanLayer.closed = false;
                                        }
                                    }

                                    if (!cleanLayer && points.length >= 2) {
                                        cleanLayer = { name, color, points };
                                        if (curve) cleanLayer.curve = curve;
                                    }

                                    if (cleanLayer) {
                                        layers.push(cleanLayer);
                                    }
                                });
                                if (layers.length) clean.layers = layers;
                            }

                            if (clean.layers) sanitizedSkins[unitKey] = clean;
                        });
                    }
                } catch (_) { }
            }
            // [R 5.1] DEFAULT_UNIT_SHAPES를 기본값으로 사용, localStorage 스킨으로 덮어쓰기
            if (typeof DEFAULT_UNIT_SHAPES !== 'undefined') {
                // 깊은 복사로 원본 보호
                window.RECLAIM_SKINS = JSON.parse(JSON.stringify(DEFAULT_UNIT_SHAPES));
                // localStorage 커스텀 스킨 병합
                Object.keys(sanitizedSkins).forEach(key => {
                    window.RECLAIM_SKINS[key] = sanitizedSkins[key];
                });
            } else {
                window.RECLAIM_SKINS = sanitizedSkins;
            }
        }
    },

    init() {
        this.ctx = this.canvas.getContext('2d');
        this.resize();
        window.addEventListener('resize', () => this.resize()); // 회전 시 즉시 반응
        window.addEventListener('orientationchange', () => setTimeout(() => this.resize(), 50));

        // [PATCH] Apply editor overrides before any game init
        this.applyLocalPatch();

        this.setupInputs();
        this.initGameObjects();

        // UI 초기화
        ui.init();
        ui.initUnitButtons(this.currentCategory);
        if (typeof Lang !== 'undefined') Lang.updateDOM();
        this.updateZoomUI();

        // [NEW] HUD 초기화
        if (typeof HUD !== 'undefined') HUD.init();

        // [P0-4] EMP 플래시 DOM 캐싱
        this.$empFlash = document.getElementById('emp-flash');
        this._empWasActive = false;
        this.$hudTimer = document.getElementById('hud-timer');
        this.$hudTimerContainer = document.getElementById('hud-timer-container');
        this.$missionModal = document.getElementById('mission-objective-modal');
        this.$missionText = document.getElementById('mission-objective-text');
        this._lastTimerText = null;
        if (this.$hudTimer) this.$hudTimer.textContent = '00:00';

        // [FIX] Force HUD selection state to null on init (prevent production UI from showing)
        this.updateHUDSelection();

        // [ADD][APP] 저장된 설정/스키마를 로드해서 게임에 적용
        if (typeof app !== 'undefined') {
            app.loadIntoGame();      // speed/difficulty/lastMapId 등 반영
            app.commit('init');      // UI 1회 정렬 + 저장 포맷 정리
        }

        // [NEW] History API Handle for Back Button
        window.addEventListener('popstate', (event) => {
            if (this.running) {
                history.pushState({ page: 'game' }, "Game", "#game");
                ui.showExitConfirmation();
            } else if (!document.getElementById('map-select-screen').classList.contains('hidden')) {
                this.backToLobby();
            } else {
                history.pushState({ page: 'lobby' }, "Lobby", "#lobby"); // Keep in page
                ui.showExitConfirmation();
            }
        });

        // Push initial state
        history.replaceState({ page: 'lobby' }, "Lobby", "#lobby");

        // Loading Sim
        this.simulateLoading();

        // Minimap Inputs
        const miniCvs = document.getElementById('hud-minimap');
        if (miniCvs) {
            const handleMinimap = (mx, my) => {
                const rect = miniCvs.getBoundingClientRect();
                const x = mx - rect.left;
                const ratio = x / rect.width;
                this.cameraX = (ratio * CONFIG.mapWidth) - (Camera.viewW(this) / 2);
                this.cameraX = Camera.clampCameraX(this, this.cameraX);
            };
            let miniDrag = false;
            miniCvs.addEventListener('mousedown', e => { miniDrag = true; handleMinimap(e.clientX, e.clientY); });
            window.addEventListener('mousemove', e => { if (miniDrag) handleMinimap(e.clientX, e.clientY); });
            window.addEventListener('mouseup', () => miniDrag = false);
        }

        // Visibility / Freeze Prevention
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                if (typeof AudioSystem !== 'undefined' && AudioSystem.ctx) AudioSystem.ctx.suspend();
                this.running = false;
                if (this.loopId) {
                    cancelAnimationFrame(this.loopId);
                    this.loopId = null;
                }
            } else {
                if (typeof AudioSystem !== 'undefined' && AudioSystem.ctx) AudioSystem.ctx.resume();
                // Resume if game was active
                if (!document.getElementById('lobby-screen').classList.contains('hidden') === false) {
                    if (this.players.length > 0 || this.buildings.length > 0) {
                        this.running = true;
                        this.loop();
                    }
                }
            }
        });
    },

    simulateLoading() {
        const bar = document.getElementById('loading-bar');
        const text = document.getElementById('loading-text');
        const btn = document.getElementById('btn-start-game');
        let progress = 0;

        const interval = setInterval(() => {
            progress += Math.random() * 5;
            if (progress > 100) progress = 100;
            if (bar) bar.style.width = `${progress}%`;

            if (progress < 30) { if (text) text.innerText = (typeof Lang !== 'undefined') ? Lang.getText('loading_system') : "System Initializing..."; }
            else if (progress < 80) { if (text) text.innerText = (typeof Lang !== 'undefined') ? Lang.getText('loading_assets') : "Loading Data..."; }
            else { if (text) text.innerText = (typeof Lang !== 'undefined') ? Lang.getText('loading_complete') : "Ready."; }

            if (progress >= 100) {
                clearInterval(interval);
                if (text) text.classList.remove('animate-pulse');
                // [변경] 로딩 끝나면 바로 시작 버튼 표시
                if (btn) btn.classList.remove('hidden');
            }
        }, 30);
    },

    completeLoading() {
        document.getElementById('loading-screen').classList.add('hidden');
        document.getElementById('lobby-screen').classList.remove('hidden');

        // [NEW] 로비 배경 초기화 및 시작
        if (typeof LobbyBackground !== 'undefined') {
            LobbyBackground.init();
            LobbyBackground.start();
        }

        // [New] Play Lobby BGM (BGM 1)
        if (typeof AudioSystem !== 'undefined') {
            AudioSystem.init();
            AudioSystem.playMP3(0);
        }
    },

    openMapSelect(mode) {
        if (mode === 'online') {
            ui.showToast(Lang.getText('online_desc'));
            return;
        }

        // [NEW] 로비 배경 정지
        if (typeof LobbyBackground !== 'undefined') {
            LobbyBackground.stop();
        }

        document.getElementById('lobby-screen').classList.add('hidden');
        document.getElementById('difficulty-select-screen')?.classList.add('hidden');
        document.getElementById('map-select-screen').classList.remove('hidden');
        this.updateMapSelectLocks();

        this.syncDifficultyButtons();
    },

    showMapSelect() {
        // [FIX] Proper transition from loading to map selection
        document.getElementById('loading-screen').classList.add('hidden');
        document.getElementById('map-select-screen').classList.remove('hidden');

        // Initialize audio on first user interaction
        if (typeof AudioSystem !== 'undefined') {
            AudioSystem.init();
            AudioSystem.playMP3(0); // Play lobby BGM
        }
        this.updateMapSelectLocks();
    },

    syncDifficultyButtons() {
        const btns = document.querySelectorAll('.btn-diff');
        if (!btns.length) return;
        const diff = (typeof AI !== 'undefined' && AI.difficulty) ? AI.difficulty : null;
        const target = diff
            ? document.querySelector(`.btn-diff[data-diff="${diff}"]`)
            : document.querySelector('.btn-diff[data-diff="veteran"]') || btns[0];
        if (target && typeof ui !== 'undefined' && typeof ui.updateDiffBtn === 'function') {
            ui.updateDiffBtn(target);
        } else if (target) {
            btns.forEach(b => b.classList.remove('active'));
            target.classList.add('active');
        }
    },

    openDifficultySelect() {
        // [NEW] 로비 배경 정지
        if (typeof LobbyBackground !== 'undefined') {
            LobbyBackground.stop();
        }

        document.getElementById('lobby-screen').classList.add('hidden');
        document.getElementById('difficulty-select-screen')?.classList.remove('hidden');
        document.getElementById('map-select-screen')?.classList.add('hidden');
        this.syncDifficultyButtons();
    },

    getUnlockedMapCount() {
        if (this.devUnlockAllMaps) return (this.mapOrder || []).length;
        if (!this.firstRunDone) return 1;
        const order = this.mapOrder || [];
        const cleared = Array.isArray(this.clearedMaps) ? this.clearedMaps : [];
        let unlocked = 1;
        for (let i = 0; i < order.length; i++) {
            if (cleared.includes(order[i])) unlocked = i + 2;
            else break;
        }
        return Math.min(order.length, unlocked);
    },

    isMapUnlocked(mapId) {
        if (this.devUnlockAllMaps) return true;
        const order = this.mapOrder || [];
        if (!order.includes(mapId)) return true;
        const unlockedCount = this.getUnlockedMapCount();
        const unlockedSet = new Set(order.slice(0, unlockedCount));
        return unlockedSet.has(mapId);
    },

    updateMapSelectLocks() {
        const order = this.mapOrder || [];
        const devUnlock = this.devUnlockAllMaps === true;
        const unlockedCount = devUnlock ? order.length : this.getUnlockedMapCount();
        const unlockedSet = new Set(order.slice(0, unlockedCount));
        const cards = document.querySelectorAll('.map-card[data-map]');
        cards.forEach(card => {
            const mapId = card.dataset.map;
            const unlocked = devUnlock || unlockedSet.has(mapId);
            card.classList.toggle('locked', !unlocked);
            if ('disabled' in card) card.disabled = !unlocked;
            card.setAttribute('aria-disabled', unlocked ? 'false' : 'true');
            const lock = card.querySelector('.map-lock');
            if (lock) lock.classList.toggle('hidden', unlocked);
        });
    },

    enableDevUnlockAllMaps() {
        if (this.devUnlockAllMaps) return;
        this.devUnlockAllMaps = true;
        this.updateMapSelectLocks();
        if (typeof ui !== 'undefined' && typeof ui.showToast === 'function') {
            ui.showToast('DEV: 모든 맵 해금');
        }
    },

    markMapCleared(mapId) {
        if (!mapId) return;
        if (!Array.isArray(this.clearedMaps)) this.clearedMaps = [];
        if (!this.clearedMaps.includes(mapId)) {
            this.clearedMaps.push(mapId);
            if (!this.firstRunDone) this.firstRunDone = true;
            if (typeof app !== 'undefined' && app.markDirty) app.markDirty();
            const screen = document.getElementById('map-select-screen');
            if (screen && !screen.classList.contains('hidden')) {
                this.updateMapSelectLocks();
            }
        }
    },

    resetProgress() {
        this.clearedMaps = [];
        this.firstRunDone = false;
        this.currentMapId = 'city';
        if (typeof app !== 'undefined') {
            app.markDirty();
            app.saveNow();
        }
        const screen = document.getElementById('map-select-screen');
        if (screen && !screen.classList.contains('hidden')) {
            this.updateMapSelectLocks();
        }
    },

    backToLobby() {
        this.running = false;
        this.isGameOver = false;
        if (this.loopId) cancelAnimationFrame(this.loopId);

        const endScreen = document.getElementById('end-screen');
        if (endScreen) { endScreen.classList.add('hidden'); endScreen.style.display = 'none'; }
        document.getElementById('hud-minimap-container').classList.add('hidden');
        document.getElementById('hud-minimap-toggle')?.classList.add('hidden');
        document.getElementById('hud-ctrl-wrapper')?.classList.add('hidden');
        document.getElementById('hud-option-btn').classList.add('hidden');
        document.getElementById('map-select-screen').classList.add('hidden');
        document.getElementById('difficulty-select-screen')?.classList.add('hidden');
        document.getElementById('unit-cmd-wrapper')?.classList.add('hidden');
        document.getElementById('unit-cmd-panel')?.classList.add('hidden');

        // [NEW] Hide fixed bottom HUD
        if (typeof HUD !== 'undefined') HUD.hide();
        if (this.$hudTimerContainer) this.$hudTimerContainer.classList.add('hidden');

        // [FIX] 로비로 복귀
        document.getElementById('lobby-screen').classList.remove('hidden');

        // [NEW] 로비 배경 재시작
        if (typeof LobbyBackground !== 'undefined') {
            LobbyBackground.start();
        }

        // Switch back to Lobby BGM
        if (typeof AudioSystem !== 'undefined') AudioSystem.playMP3(0);
    },

    // [R 2.2] 유닛 도감 열기
    openUnitDex() {
        // [NEW] 로비 배경 정지
        if (typeof LobbyBackground !== 'undefined') {
            LobbyBackground.stop();
        }

        document.getElementById('lobby-screen').classList.add('hidden');
        document.getElementById('unitdex-screen').classList.remove('hidden');
        if (typeof UnitDex !== 'undefined') UnitDex.render();
    },

    // [R 2.2] 유닛 도감 닫기
    closeUnitDex() {
        document.getElementById('unitdex-screen').classList.add('hidden');
        document.getElementById('lobby-screen').classList.remove('hidden');

        // [NEW] 로비 배경 재시작
        if (typeof LobbyBackground !== 'undefined') {
            LobbyBackground.start();
        }
    },

    startGame(mapType) {
        const nextMap = mapType || 'plain';
        if (!this.isMapUnlocked(nextMap)) {
            if (typeof ui !== 'undefined') ui.showToast('LOCKED');
            this.updateMapSelectLocks();
            return;
        }
        document.getElementById('map-select-screen').classList.add('hidden');
        Maps.currentMap = nextMap;

        // [NEW] 맵 규칙에 따른 옵션 자동 설정
        const mapExpand = (typeof Maps !== 'undefined') ? Maps.getRule('mapExpand') : false;
        const hasPlayerDefense = (typeof Maps !== 'undefined') ? Maps.getRule('playerDefense') : true;
        const optDefense = document.getElementById('opt-forward-defense');

        // 방어시설 옵션: 맵에서 허용되면 적용 (옵션 없으면 맵 규칙에 따름)
        const forceDefense = !optDefense && (hasPlayerDefense || (typeof Maps !== 'undefined' && Maps.getRule('enemyDefense')));
        this.settings.includeForwardDefense = (hasPlayerDefense || (typeof Maps !== 'undefined' && Maps.getRule('enemyDefense')))
            && (optDefense ? !!optDefense.checked : forceDefense);

        // [NEW] 맵 가로폭 동적 확장 (맵 규칙 또는 방어시설 옵션에 따라)
        const baseW = CONFIG.baseMapWidth || CONFIG.mapWidth || 6000;
        let extraW = 0;
        if (mapExpand) {
            extraW = CONFIG.defenseExtraWidth || 1500; // 맵 규칙에 의한 확장
        } else if (this.settings.includeForwardDefense) {
            extraW = CONFIG.defenseExtraWidth || 0; // 방어시설 옵션에 의한 확장
        }
        CONFIG.mapWidth = baseW + extraW;

        // [NEW] 마지막 선택 맵 저장
        this.currentMapId = nextMap;

        this.start();
    },

    // [핵심] 흔들림 없는 리사이즈 로직
    resize() {
        const wrapper = document.getElementById('game-wrapper');
        const winW = window.innerWidth;
        const winH = window.innerHeight;
        const prevViewW = Camera.viewW(this);

        // 1. 배율 계산 (세로 높이를 720px에 맞춤)
        // 화면이 작으면 알아서 축소(Zoom Out)되고, 크면 확대됩니다.
        this.scaleRatio = winH / LOGICAL_HEIGHT;

        // 2. 가로 길이 계산 (화면 비율에 따라 유동적으로 넓어짐)
        // 예: 가로 모드면 width가 1400px 이상으로 늘어나서 PC처럼 보임
        this.width = winW / this.scaleRatio;
        this.height = LOGICAL_HEIGHT; // 높이는 무조건 720 고정!

        // 3. 캔버스 크기 적용
        this.canvas.width = this.width;
        this.canvas.height = this.height;

        // 4. 땅 높이 고정 (절대 변하지 않음)
        // 화면을 돌려도 groundY는 항상 470px (720 - 250) 입니다.
        this.groundY = this.height - CONFIG.groundHeight;

        // 5. CSS 스타일 적용 (화면 꽉 채우기)
        if (wrapper) {
            wrapper.style.width = `${winW}px`;
            wrapper.style.height = `${winH}px`;
            // wrapper 자체를 scale로 줄이거나 늘려서 딱 맞춤
            // transform 대신 캔버스 내부 해상도를 조절했으므로 여기선 크기만 맞춤
            wrapper.style.transform = 'none';

            // 캔버스 스타일 강제 지정 (중요)
            this.canvas.style.width = '100%';
            this.canvas.style.height = '100%';
        }

        Camera.preserveCenterOnResize(this, prevViewW);
    },

    initGameObjects() {
        // [NEW] Difficulty Stock Logic
        let stockMult = 1.0;
        let diff = 'veteran';
        if (typeof AI !== 'undefined' && AI.difficulty) diff = AI.difficulty;

        if (diff === 'recruit') {
            stockMult = 1.2; // 120%
        } else if (diff === 'elite') {
            stockMult = 0.6; // 60%
            console.log("Elite Difficulty: Player Stock Reduced to 60%");
        }

        for (let k in CONFIG.units) {
            this.cooldowns[k] = 0; this.enemyCooldowns[k] = 0;
            const isDroneKey = k.includes('drone');

            // [SPECIAL] 스텔스드론: 아군/적군 모두 5기 고정
            if (k === 'stealth_drone') {
                const fixedCount = Math.ceil(5 * 1.1);
                this.playerStock[k] = fixedCount;
                this.enemyStock[k] = fixedCount;
                this.spawnQueue[k] = 0;
                continue;
            }

            // Apply Multiplier
            let finalCount = Math.ceil(CONFIG.units[k].maxCount * stockMult);

            // [3.8] 작업자는 항상 최대 1명 고정 (난이도 보정 무시)
            if (k === 'worker') {
                finalCount = 1;
            }

            // [BUFF] Elite 난이도: 아군 드론 재고 보정
            if (diff === 'elite') {
                const unitDef = CONFIG.units[k];
                const isDroneUnit = (unitDef.category === 'drone' || (unitDef.id && unitDef.id.includes('drone'))) && !unitDef.operator;
                if (isDroneUnit) {
                    finalCount = Math.max(finalCount, Math.ceil(CONFIG.units[k].maxCount * 1.0) + 1);
                }
            }

            // [NERF] Elite SPG Cap
            if (diff === 'elite' && k === 'spg') {
                finalCount = Math.min(finalCount, 3); // Max 3 SPGs on Elite
            }

            if (isDroneKey) {
                finalCount = Math.ceil(finalCount * 1.1);
            }

            this.playerStock[k] = finalCount;
            let enemyCount = Math.ceil(CONFIG.units[k].maxCount * 1.5);
            if (k === 'drone_suicide' || k === 'drone_at') {
                enemyCount = Math.ceil(enemyCount * 0.5);
            }
            if (isDroneKey) {
                enemyCount = Math.ceil(enemyCount * 1.1);
            }
            this.enemyStock[k] = enemyCount;
            this.spawnQueue[k] = 0;
        }

        this.totalWarTriggered = false; // Reset Total War
        this.cityArmorNewsShown = false;
        this.cityMidNewsShown = false;
        this.cityTotalWarNewsShown = false;

        // [NEW] 공습경보 상태 초기화
        this.airRaidWarning = null;
    },

    // [NEW] 적군 총력전 (Total War) 트리거
    triggerTotalWar() {
        if (this.totalWarTriggered || !this.running) return;
        this.totalWarTriggered = true;

        // [R 4.2] 스폰 금지 유닛 리스트
        const BLOCKED_UNITS = ['tactical_drone', 'stealth_drone', 'drone_suicide', 'drone_at'];

        let delayCount = 0;
        const enemyHQ = this.buildings.find(b => b.type === 'hq_enemy');
        const spawnX = enemyHQ ? enemyHQ.x : CONFIG.mapWidth;

        for (let key in this.enemyStock) {
            // [R 4.2] disabled 유닛 및 BLOCKED_UNITS 스킵
            const unitDef = CONFIG.units[key];
            if (!unitDef) continue;
            if (unitDef.disabled === true) continue;
            if (BLOCKED_UNITS.includes(key)) continue;

            const count = this.enemyStock[key];
            for (let i = 0; i < count; i++) {
                setTimeout(() => {
                    if (this.running) {
                        this.spawnUnitDirect(key, spawnX - 50 + (Math.random() * 60 - 30), this.groundY, 'enemy');
                    }
                }, delayCount * 150);
                delayCount++;
            }
            this.enemyStock[key] = 0;
        }
    },

    start() {
        // [FIX] ID 수정: start-screen은 존재하지 않으므로 loading-screen을 숨김
        document.getElementById('loading-screen')?.classList.add('hidden');
        document.getElementById('lobby-screen')?.classList.add('hidden');
        document.getElementById('end-screen').classList.add('hidden');

        // [New] Push history state when game starts
        history.pushState({ page: 'game' }, "Game", "#game");

        this.players = []; this.enemies = []; this.civilians = []; this.projectiles = []; this.particles = [];
        this.buildings = [];
        this.supply = CONFIG.startSupply; this.enemySupply = CONFIG.startSupply;
        this.empTimer = 0;
        this.skillCharges = { emp: 5, nuke: 1, tactical: 5 };
        this.killCount = 0;
        this.isGameOver = false;
        this.enemyEverSeen = false;
        this.playerEverSeen = false;
        this.watchtowerBuilt = false;  // [3.8] 감시탑 1회 건설 제한 초기화
        this.civilianDeaths = 0;
        this.airRaidTriggered = false;
        this.civilianEvacActive = false;
        this.civilianEvacX = null;
        if (this.airRaidBomberTimeout) {
            clearTimeout(this.airRaidBomberTimeout);
            this.airRaidBomberTimeout = null;
        }
        if (typeof AudioSystem !== 'undefined') {
            AudioSystem.panicMuted = false;
        }
        this.frame = 0;
        this._lastTimerText = null;
        if (this.$hudTimerContainer) {
            this.$hudTimerContainer.classList.remove('hidden');
        }
        if (this.$hudTimer) {
            this.$hudTimer.textContent = '00:00';
        }
        // [NEW] 맵별 임무 목표 텍스트 설정
        this._updateMissionObjectiveText();

        // Recalculate groundY fresh to be sure
        this.resize();

        // [Safety] Ensure Map is selected
        if (typeof Maps !== 'undefined' && !Maps.currentMap) Maps.currentMap = 'plain';

        this.initGameObjects();
        this.running = true;
        this.cameraX = 0;

        // HUD
        this.minimapVisible = true;
        // [CHANGE] Hide old floating UI, use fixed HUD instead
        document.getElementById('hud-minimap-container')?.classList.add('hidden');
        document.getElementById('hud-minimap-toggle')?.classList.add('hidden');
        document.getElementById('hud-ctrl-wrapper')?.classList.add('hidden');
        document.getElementById('hud-option-btn').classList.remove('hidden');
        document.getElementById('unit-cmd-wrapper')?.classList.add('hidden');
        if (typeof ui !== 'undefined') ui.updateSpeedBtns(this.speed);

        // [NEW] Show fixed bottom HUD
        if (typeof HUD !== 'undefined') HUD.show();

        // In-game BGM
        if (typeof AudioSystem !== 'undefined') {
            if (AudioSystem.stopBGM) AudioSystem.stopBGM();
            if (Maps.currentMap === 'city' && AudioSystem.playBGMFile) {
                AudioSystem.playBGMFile('bgm/city.mp3');
            }
        }

        // AI
        if (typeof AI !== 'undefined') AI.lastSpawn = 0;

        // [NEW] Map Setup - 맵별 규칙에 따른 건물 배치
        const rearX = 120;  // HQ(후방)
        const forwardShift = 120;
        const frontX = 520 + forwardShift;
        const towerX = frontX + 450;

        // 맵 규칙 가져오기
        const hasPlayerHQ = (typeof Maps !== 'undefined') ? Maps.getRule('playerHQ') : true;
        const hasEnemyHQ = (typeof Maps !== 'undefined') ? Maps.getRule('enemyHQ') : true;
        const hasPlayerDefense = (typeof Maps !== 'undefined') ? Maps.getRule('playerDefense') : true;
        const hasEnemyDefense = (typeof Maps !== 'undefined') ? Maps.getRule('enemyDefense') : true;
        const hasBunkers = (typeof Maps !== 'undefined') ? Maps.getRule('bunkers') : true;

        // 아군 HQ (맵 규칙에 따라)
        if (hasPlayerHQ) {
            this.buildings.push(new Building('hq_player', rearX, this.groundY, 'player'));
        }

        // 아군 방어시설 (맵 규칙 + 옵션 체크)
        if (hasPlayerDefense && this.settings.includeForwardDefense) {
            const fortressExtraX = 180;
            const fortressX = frontX + fortressExtraX;
            this.buildings.push(new Building('fortress_player', fortressX, this.groundY, 'player'));
            this.buildings.push(new Building('watchtower', towerX, this.groundY, 'player'));
        }

        // 적군 HQ (맵 규칙에 따라)
        if (hasEnemyHQ) {
            this.buildings.push(new Building('hq_enemy', CONFIG.mapWidth - rearX, this.groundY, 'enemy'));
        }

        // 적군 방어시설 (맵 규칙 + 옵션 체크)
        if (hasEnemyDefense && this.settings.includeForwardDefense) {
            const fortressExtraX = 180;
            const fortressX = frontX + fortressExtraX;
            this.buildings.push(new Building('fortress_enemy', CONFIG.mapWidth - fortressX, this.groundY, 'enemy'));
            this.buildings.push(new Building('watchtower', CONFIG.mapWidth - towerX, this.groundY, 'enemy'));
        }

        // 거점 건물 (맵 규칙에 따라)
        if (hasBunkers) {
            const bunkerRatios = [0.3, 0.5, 0.7];
            bunkerRatios.forEach(ratio => {
                const bunker = new Building('bunker', CONFIG.mapWidth * ratio, this.groundY, 'neutral');
                if (typeof Maps !== 'undefined' && Maps.currentMap === 'city') {
                    if (Math.abs(ratio - 0.5) < 0.0001) {
                        bunker.variant = 'luxury';
                    } else if (Math.abs(ratio - 0.3) < 0.0001) {
                        bunker.variant = 'legacy';
                    } else if (Math.abs(ratio - 0.7) < 0.0001) {
                        bunker.variant = 'legacy';
                    }
                }
                this.buildings.push(bunker);
            });
        }

        // [CITY] Right-side defense line in front of the far bunker (player only)
        if (typeof Maps !== 'undefined' && Maps.currentMap === 'city') {
            const rightBunkerX = CONFIG.mapWidth * 0.7;
            const defenseOffset = 260;
            const defenseX = Math.min(CONFIG.mapWidth - 200, rightBunkerX + defenseOffset);
            const defense = new Building('defense_line', defenseX, this.groundY, 'player');

            const diff = (typeof AI !== 'undefined' && AI.difficulty) ? AI.difficulty : 'veteran';
            let hpScale = 1.0;
            let dmgScale = 1.0;
            if (diff === 'recruit') {
                hpScale = 1.6;
                dmgScale = 1.2;
            } else if (diff === 'elite') {
                hpScale = 0.7;
                dmgScale = 0.7;
            }
            defense.maxHp = Math.round(defense.maxHp * hpScale);
            defense.hp = defense.maxHp;
            defense.damage = Math.round(defense.damage * dmgScale);

            this.buildings.push(defense);
        }

        if (typeof Maps !== 'undefined' && Maps.currentMap === 'city') {
            this.spawnCityCivilians();
        }
        if (typeof Maps !== 'undefined' && Maps.currentMap === 'city') {
            if (typeof NewsOverlay !== 'undefined') NewsOverlay.hide();
            if (typeof NewsIntro !== 'undefined') {
                NewsIntro.schedule(7000, 3000, () => {
                    if (typeof NewsOverlay !== 'undefined') {
                        NewsOverlay.show(9000);
                    }
                });
            } else if (typeof NewsOverlay !== 'undefined') {
                NewsOverlay.schedule(10000, 9000);
            }
        } else {
            if (typeof NewsIntro !== 'undefined') NewsIntro.hide();
            if (typeof NewsOverlay !== 'undefined') NewsOverlay.hide();
        }
        // [R 4.2] 시작 속도 무조건 0.5배속
        this.setSpeed(0.5);
        this.engineFrame = 0;

        // [R 4.2] ChatPanel 초기화 및 표시
        if (typeof ChatPanel !== 'undefined') {
            ChatPanel.init();
            ChatPanel.show();
            ChatPanel.push('작전 개시. 행운을 빌니다.', 'INFO');
        }

        this.loop();
    },

    setupInputs() {
        // [R 2.4] 완전 재설계된 입력 시스템
        const getScaledPos = (clientX, clientY) => {
            return Camera.screenToView(this, clientX, clientY);
        };

        // [NEW] Check if click/touch is inside HUD area (input blocking)
        const isInsideHUD = (clientY) => {
            const hudFooter = document.getElementById('hud-footer');
            if (!hudFooter || hudFooter.classList.contains('hidden')) return false;
            const rect = hudFooter.getBoundingClientRect();
            return clientY >= rect.top;
        };

        // ======== 상태 변수 ========
        // 카메라 드래그 (PC 우클릭 / 모바일 두 손가락)
        let cameraDrag = false;
        let cameraLastX = 0;

        // 선택 박스 드래그 (PC 좌클릭 / 모바일 한 손가락)
        this.selectDragActive = false;
        this.selectStartX = 0;
        this.selectStartY = 0;
        this.selectEndX = 0;
        this.selectEndY = 0;

        // 모바일 전용 상태
        let isMobileSelecting = false;
        let isMobileCameraMove = false;
        let pinchActive = false;
        let pinchStartDist = 0;
        let pinchStartZoom = Camera.zoom;
        let pinchAnchorClientX = 0;
        let pinchAnchorClientY = 0;

        // [MOBILE TAP FIX] 탭/드래그 판정은 월드좌표가 아니라 "픽셀" 기준으로 한다
        let tapStartClientX = 0, tapStartClientY = 0;
        let tapLastClientX = 0, tapLastClientY = 0;
        const TAP_THRESHOLD_PX = 14; // 12~18 사이 취향, 14 추천

        // [MODIFIED] 건물 선택 (플레이어 건설 건물 포함)
        const selectBuildingAt = (wx, wy) => {
            // 선택 가능한 건물 타입들
            const selectableTypes = [
                'hq_player', 'hq_enemy', 'fortress_player', 'fortress_enemy',
                'watchtower'  // [3.8] 플레이어 건설 감시탑
            ];

            for (let b of this.buildings) {
                if (b.dead) continue;
                // 기존 타입 또는 canProduce 플래그가 있는 건물만 선택 가능
                if (!selectableTypes.includes(b.type) && !b.canProduce && !b.canShoot) continue;
                // [FIX] 클릭 범위 확대 (좌우 +20px, 상하 +15px)
                const padX = 20;
                const padY = 15;
                if (wx > b.x - b.width / 2 - padX && wx < b.x + b.width / 2 + padX &&
                    wy > b.y - b.height - padY && wy < b.y + padY) {
                    this.selectedBuilding = b;
                    b.hideHp = false;
                    b.hpVisibleUntil = game.frame + 180;
                    // [NEW] Update HUD
                    this.updateHUDSelection();
                    return true;
                }
            }
            this.selectedBuilding = null;
            // [NEW] Update HUD
            this.updateHUDSelection();
            return false;
        };
        // Alias for backward compatibility
        const selectHQAt = selectBuildingAt;

        const getTouchDist = (t1, t2) => Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
        const getTouchMid = (t1, t2) => ({
            x: (t1.clientX + t2.clientX) / 2,
            y: (t1.clientY + t2.clientY) / 2
        });

        // ======== PC 마우스 이벤트 ========
        this.canvas.addEventListener('mousedown', e => {
            // [NEW] Block if inside HUD area
            if (isInsideHUD(e.clientY)) return;

            const p = getScaledPos(e.clientX, e.clientY);
            if (p.x < 0 || p.x > this.width || p.y < 0 || p.y > this.height) return;

            if (e.button === 2) {
                // [NEW] PC 우클릭: 선택 유닛 이동 (기본 RTS 방식)
                if (this.selectedUnits && this.selectedUnits.size > 0 && !this.buildMode.active && !this.targetingType) {
                    const worldX = p.x + this.cameraX;
                    const worldY = p.y;

                    this.selectedUnits.forEach(u => {
                        if (!u || u.dead) return;
                        u.commandMode = 'move';
                        u.commandTargetX = worldX; // ★ 반드시 갱신 (facing용)
                        u.targetX = worldX;
                        u.targetY = null;
                        u.lockedTarget = null;
                        u.attackTarget = null;
                        if (u.stats && !u.stats.operator && (u.stats.category === 'drone' || (u.stats.id && u.stats.id.includes('drone')))) {
                            u.swarmTarget = { x: worldX, y: worldY };
                        }
                    });

                    // particles + move marker
                    this.createParticles(worldX, this.groundY - 10, 10, '#22c55e');
                    this.moveEffects = this.moveEffects || [];
                    this.moveEffects.push({ x: p.x, y: p.y, radius: 22, life: 1.0 });

                    return;
                }

                // (선택 유닛 없으면) 우클릭: 카메라 드래그 유지
                cameraDrag = true;
                cameraLastX = p.x;
            } else if (e.button === 0) {
                // [NEW] 건설 모드 중이면 배치 처리
                if (this.buildMode.active) {
                    this.handleBuildPlacement(p.x + this.cameraX);
                    return;
                }
                // 좌클릭: 타겟팅 중이면 타겟팅 처리
                if (this.targetingType) {
                    this.handleTargeting(p.x + this.cameraX, p.y);
                    return;
                }
                // 선택 박스 드래그 시작
                this.selectDragActive = true;
                this.selectStartX = p.x + this.cameraX;
                this.selectStartY = p.y;
                this.selectEndX = this.selectStartX;
                this.selectEndY = this.selectStartY;
            }
        });

        window.addEventListener('mousemove', e => {
            const p = getScaledPos(e.clientX, e.clientY);

            // [NEW] 건설 모드 프리뷰 업데이트
            if (this.buildMode.active) {
                this.updateBuildPreview(p.x + this.cameraX, p.y);
            }

            // 카메라 드래그 (우클릭)
            if (cameraDrag && !this.selectDragActive) {
                this.cameraX -= (p.x - cameraLastX);
                this.cameraX = Camera.clampCameraX(this, this.cameraX);
                cameraLastX = p.x;
            }

            // 선택 박스 갱신 (좌클릭)
            if (this.selectDragActive) {
                this.selectEndX = p.x + this.cameraX;
                this.selectEndY = p.y;
            }
        });

        window.addEventListener('mouseup', e => {
            if (e.button === 2) {
                cameraDrag = false;
            } else if (e.button === 0 && this.selectDragActive) {
                this.selectDragActive = false;
                // 선택 박스가 너무 작으면 단일 클릭으로 처리
                const dx = Math.abs(this.selectEndX - this.selectStartX);
                const dy = Math.abs(this.selectEndY - this.selectStartY);
                if (dx < 10 && dy < 10) {
                    // 단일 클릭: 기존 클릭 로직
                    const clickX = this.selectStartX;
                    const clickY = this.selectStartY;
                    if (this.tryDroneLockdown && this.tryDroneLockdown(clickX, clickY)) return;
                    if (selectHQAt(clickX, clickY)) return;
                    const unitClicked = this.checkUnitClick && this.checkUnitClick(clickX, clickY);
                    if (unitClicked) { this.selectedBuilding = null; return; }
                    if (this.checkBuildingClick) this.checkBuildingClick(clickX, clickY);
                    if (this.clearAllSelection) this.clearAllSelection();
                    this.selectedBuilding = null;
                } else {
                    // 드래그 선택: 박스 내 유닛 선택
                    if (this.selectUnitsInRect) this.selectUnitsInRect();
                    this.selectedBuilding = null;
                }
            }
        });

        // 우클릭 메뉴 차단 + 드론 명령 + 건설 취소
        this.canvas.addEventListener('contextmenu', e => {
            e.preventDefault();
            // [NEW] Block if inside HUD area
            if (isInsideHUD(e.clientY)) return;

            // [NEW] 건설 모드 취소
            if (this.buildMode.active) {
                this.cancelBuildMode();
                ui.showToast('건설 취소');
                return;
            }

            const p = getScaledPos(e.clientX, e.clientY);
            this.commandDrones(p.x + this.cameraX, p.y);
        });

        this.canvas.addEventListener('wheel', e => {
            e.preventDefault();
            const step = e.deltaY < 0 ? Camera.STEP : -Camera.STEP;
            const newZoom = Camera.zoom + step;
            const prevZoom = Camera.zoom;
            Camera.applyZoomWithAnchor(this, newZoom, e.clientX, e.clientY);
            if (Camera.zoom !== prevZoom) this.updateZoomUI();
        }, { passive: false });

        // ======== 모바일 터치 이벤트 ========
        this.canvas.addEventListener('touchstart', e => {
            e.preventDefault();

            // [NEW] Block if any touch is inside HUD area
            for (let i = 0; i < e.touches.length; i++) {
                if (isInsideHUD(e.touches[i].clientY)) return;
            }

            if (e.touches.length === 1) {
                // 단일 터치: 유닛 선택 모드 (카메라 이동 금지)
                isMobileSelecting = true;
                isMobileCameraMove = false;
                pinchActive = false;

                const p = getScaledPos(e.touches[0].clientX, e.touches[0].clientY);
                if (p.x < 0 || p.x > this.width || p.y < 0 || p.y > this.height) return;

                // [NEW] 건설 모드 중이면 배치 처리
                if (this.buildMode.active) {
                    this.updateBuildPreview(p.x + this.cameraX, p.y);
                    this.handleBuildPlacement(p.x + this.cameraX);
                    isMobileSelecting = false;
                    return;
                }

                // 타겟팅 중이면 타겟팅 처리
                if (this.targetingType) {
                    this.handleTargeting(p.x + this.cameraX, p.y);
                    isMobileSelecting = false;
                    return;
                }

                // 선택 박스 시작
                this.selectDragActive = true;
                this.selectStartX = p.x + this.cameraX;
                this.selectStartY = p.y;
                this.selectEndX = this.selectStartX;
                this.selectEndY = this.selectStartY;

                // [MOBILE TAP FIX] 탭 판정용 픽셀 좌표 기록
                tapStartClientX = tapLastClientX = e.touches[0].clientX;
                tapStartClientY = tapLastClientY = e.touches[0].clientY;

            } else if (e.touches.length >= 2) {
                // 두 손가락: 카메라 이동 모드
                isMobileCameraMove = true;
                isMobileSelecting = false;
                this.selectDragActive = false;

                const t1 = e.touches[0];
                const t2 = e.touches[1];
                pinchActive = true;
                pinchStartDist = getTouchDist(t1, t2);
                pinchStartZoom = Camera.zoom;
                const mid = getTouchMid(t1, t2);
                pinchAnchorClientX = mid.x;
                pinchAnchorClientY = mid.y;

                const p = getScaledPos(t1.clientX, t1.clientY);
                cameraLastX = p.x;
            }
        }, { passive: false });

        window.addEventListener('touchmove', e => {
            // 모바일 선택 중: 카메라 이동 완전 차단
            if (isMobileSelecting && this.selectDragActive) {
                e.preventDefault();
                const p = getScaledPos(e.touches[0].clientX, e.touches[0].clientY);
                this.selectEndX = p.x + this.cameraX;
                this.selectEndY = p.y;

                // [MOBILE TAP FIX] 마지막 픽셀 좌표 갱신
                tapLastClientX = e.touches[0].clientX;
                tapLastClientY = e.touches[0].clientY;

                return; // 카메라 로직 호출 금지
            }

            // 두 손가락 카메라 이동
            if (isMobileCameraMove && e.touches.length >= 2) {
                if (pinchActive) {
                    e.preventDefault();
                    const t1 = e.touches[0];
                    const t2 = e.touches[1];
                    const dist = getTouchDist(t1, t2);
                    if (pinchStartDist > 0) {
                        const newZoom = pinchStartZoom * (dist / pinchStartDist);
                        const prevZoom = Camera.zoom;
                        Camera.applyZoomWithAnchor(this, newZoom, pinchAnchorClientX, pinchAnchorClientY);
                        if (Camera.zoom !== prevZoom) this.updateZoomUI();
                    }
                    return;
                }

                const p = getScaledPos(e.touches[0].clientX, e.touches[0].clientY);
                this.cameraX -= (p.x - cameraLastX);
                this.cameraX = Camera.clampCameraX(this, this.cameraX);
                cameraLastX = p.x;
            }
        }, { passive: false });

        window.addEventListener('touchend', e => {
            if (isMobileSelecting && this.selectDragActive) {
                this.selectDragActive = false;
                isMobileSelecting = false;

                // [MOBILE TAP FIX] 월드좌표(dx,dy)로 탭 판정하면 모바일에서 거의 항상 드래그로 오인됨
                // 픽셀 기준으로 탭/드래그 판정
                const ct = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0] : null;
                const endClientX = ct ? ct.clientX : tapLastClientX;
                const endClientY = ct ? ct.clientY : tapLastClientY;
                const movedPx = Math.hypot(endClientX - tapStartClientX, endClientY - tapStartClientY);

                if (movedPx < TAP_THRESHOLD_PX) {
                    // 단일 탭: "끝 좌표"를 기준으로 클릭 처리(더 정확)
                    const pTap = getScaledPos(endClientX, endClientY);
                    const clickX = pTap.x + this.cameraX;
                    const clickY = pTap.y;

                    if (this.tryDroneLockdown && this.tryDroneLockdown(clickX, clickY)) return;
                    if (selectHQAt(clickX, clickY)) return;
                    const unitClicked = this.checkUnitClick && this.checkUnitClick(clickX, clickY);
                    if (unitClicked) { this.selectedBuilding = null; return; }
                    if (this.checkBuildingClick) this.checkBuildingClick(clickX, clickY);
                    if (this.clearAllSelection) this.clearAllSelection();
                    this.selectedBuilding = null;
                } else {
                    // 드래그 선택
                    if (this.selectUnitsInRect) this.selectUnitsInRect();
                    this.selectedBuilding = null;
                }
            }

            if (e.touches.length === 0) {
                isMobileCameraMove = false;
                cameraDrag = false;
                pinchActive = false;
            } else if (e.touches.length < 2) {
                pinchActive = false;
            }
        });

        // [NEW] ESC 키로 건설/타겟팅 모드 취소
        window.addEventListener('keydown', e => {
            if (e.key === 'Escape') {
                if (this.buildMode.active) {
                    this.cancelBuildMode();
                    ui.showToast('건설 취소');
                } else if (this.targetingType) {
                    this.cancelTargeting();
                }
                return;
            }

            if (e.key === 'p' || e.key === 'P') {
                if (e.repeat) return;
                const now = (performance.now ? performance.now() : Date.now());
                const windowMs = 700;
                if (now - (this._devLastPPressAt || 0) <= windowMs) {
                    this._devPPressCount = (this._devPPressCount || 0) + 1;
                } else {
                    this._devPPressCount = 1;
                }
                this._devLastPPressAt = now;
                if (this._devPPressCount >= 2) {
                    this._devPPressCount = 0;
                    this.enableDevUnlockAllMaps();
                }
            }
        });
    },

    setCategory(cat) {
        this.currentCategory = cat;
        // UI 갱신은 commit에서 처리
        if (typeof app !== 'undefined') app.markUiDirty();
    },

    // [FIX] Bunker Spawn Selection Stub (Prevent Crash)
    selectSpawn(bunker) {
        // Feature removed, but keeping method to prevent buildings.js crash
        this.selectedSpawn = bunker;
    },

    spawnUnitExecution(key) {
        const hq = this.buildings.find(b => b.type === 'hq_player');
        if (!hq) return;
        this.spawnUnitDirect(key, hq.x + 50, this.groundY, 'player');
    },

    prepareTargeting(key) {
        if (this.targetingType) return;
        const u = CONFIG.units[key];
        if (u.isSkill) {
            if (this.skillCharges[u.chargeKey] <= 0) { ui.showToast("사용 가능 횟수 부족!"); return; }
        } else {
            if (this.supply < u.cost || this.playerStock[key] <= 0) { ui.showToast("자원 또는 재고 부족!"); return; }
        }
        this.targetingType = key;
        document.getElementById('targeting-overlay').classList.remove('hidden');
        const strikeKeys = ['nuke', 'emp', 'tactical_missile', 'stealth_drone'];
        const msg = strikeKeys.includes(key)
            ? '타격지점을 선택하십시요'
            : '목표지점을 선택하십시요';
        document.getElementById('target-msg').innerText = msg;
        if (typeof app !== 'undefined') app.markUiDirty();
    },

    handleTargeting(x, y) {
        if (!this.targetingType) return;
        const key = this.targetingType;

        // [FIX] move는 CONFIG.units에 없는 가짜 키
        if (key === '__move__') {
            this.handleMoveTargeting(x);
            this.cancelTargeting();
            return;
        }

        // [NEW] smoke grenade targeting
        if (key === '__smoke__') {
            this.handleSmokeTargeting(x, y);
            this.cancelTargeting();
            return;
        }

        const u = CONFIG.units[key];
        if (!u) {
            console.warn('[TARGETING] Unknown targetingType:', key);
            this.cancelTargeting();
            return;
        }

        if (key === 'nuke') {
            if (this.skillCharges.nuke > 0) {
                this.skillCharges.nuke--;
                // (옵션) 쿨타임이 있다면 반영
                if (u.cooldown && u.cooldown > 0) this.cooldowns.nuke = u.cooldown;

                // ✅ [NEW] 핵 발사 전 경고음 + 5초 지연
                ui.showToast("⚠️ 전술핵 발사 승인! 5초 후 투하!");

                // 경고음 재생 (5초간 사이렌)
                if (typeof AudioSystem !== 'undefined') AudioSystem.playNukeWarning();

                // 5초 후 실제 핵 발사
                const targetX = x;
                const groundY = this.groundY;
                setTimeout(() => {
                    const nuke = new Projectile(targetX, -500, null, 1000, 'player', 'nuke');
                    nuke.targetX = targetX;
                    nuke.targetY = groundY;
                    this.projectiles.push(nuke);

                    ui.showToast("☢️ 전술핵 투하!");
                }, 5000);

                // [FIX] 스킬은 큐/쿨타임이 없으면 uiDirty가 안 떠서 숫자 갱신이 안 됨
                if (typeof app !== 'undefined') { app.markDirty(); app.markUiDirty(); }
            }
        } else if (key === 'emp') {
            if (this.skillCharges.emp > 0) {
                this.skillCharges.emp--;
                if (u.cooldown && u.cooldown > 0) this.cooldowns.emp = u.cooldown;
                ui.showToast("EMP 충격파 발생!");
                const targets = [...this.enemies, ...this.enemyBuildings];
                targets.forEach(e => { if (!e.dead && Math.abs(e.x - x) < 300 && (e.stats.type === 'mech' || e.stats.type === 'building')) e.stunTimer = 600; });
                this.createParticles(x, y, 20, '#ffffff');

                if (typeof app !== 'undefined') { app.markDirty(); app.markUiDirty(); }
            }
        } else if (key === 'tactical_missile') {
            if (this.skillCharges.tactical > 0) {
                this.skillCharges.tactical--;
                if (u.cooldown && u.cooldown > 0) this.cooldowns.tactical_missile = u.cooldown;

                // 타겟이 지면 아래면 보정
                const ty = Math.min(y, this.groundY);

                // ✅ 본부에서 발사
                const hq = this.buildings.find(b => b.type === 'hq_player');
                const sx = hq ? (hq.x + hq.width * 0.55) : 80;
                const sy = hq ? (this.groundY - (hq.height * 0.85)) : (this.groundY - 260);

                const m = new Projectile(sx, sy, null, 0, 'player', 'tactical_missile', { targetX: x, targetY: ty });
                this.projectiles.push(m);

                ui.showToast("전술미사일 발사!");

                if (typeof app !== 'undefined') { app.markDirty(); app.markUiDirty(); }
            }
        } else if (key === 'stealth_drone') {
            // 위치 지정형 (락온 없음): 지정 지점으로 침투 후 급강하 폭발
            this.supply -= u.cost;
            this.cooldowns[key] = u.cooldown;
            this.playerStock[key]--;

            const drone = new Unit(key, 50, this.groundY, 'player', null);
            drone.x = 50;
            drone.y = this.groundY - 420;
            drone.targetX = x;
            this.players.push(drone);
            ui.showToast(`${u.name} 출격!`);

            // [FIX] 재고/공급/쿨타임 UI 즉시 반영
            if (typeof app !== 'undefined') { app.markDirty(); app.markUiDirty(); }
        } else {
            let target = null;
            let minDist = 300;
            const validTargets = [...this.enemies, ...this.enemyBuildings];
            validTargets.forEach(e => {
                const dy = e.y - (e.height ? e.height / 2 : 0) - y;
                const dx = e.x - x;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < minDist) { minDist = d; target = e; }
            });

            if (u.lockOn && !target) { ui.showToast("타겟을 찾을 수 없습니다!"); return; }

            this.supply -= u.cost;
            this.cooldowns[key] = u.cooldown;
            this.playerStock[key]--;

            const drone = new Unit(key, 50, this.groundY, 'player', target);
            if (key === 'blackhawk' || key === 'chinook') {
                drone.x = 40;
                drone.y = this.groundY - 190;
                drone.targetX = x;
                drone.targetY = this.groundY - 190;
            } else if (!target) {
                drone.x = x; drone.y = y;
            }
            this.players.push(drone);
            ui.showToast(`${u.name} 출격!`);

            // [FIX] 재고/공급/쿨타임 UI 즉시 반영
            if (typeof app !== 'undefined') { app.markDirty(); app.markUiDirty(); }
        }
        this.cancelTargeting();
    },

    cancelTargeting() {
        this.targetingType = null;
        document.getElementById('targeting-overlay').classList.add('hidden');
    },

    // ============================================
    // [NEW] 이동 명령 타겟팅 시작
    // ============================================
    prepareMoveCommand() {
        if (!this.selectedUnits || this.selectedUnits.size === 0) {
            ui.showToast('유닛을 먼저 선택하세요');
            return;
        }
        if (this.targetingType) return; // 이미 타겟팅 중

        this.targetingType = '__move__';
        document.getElementById('targeting-overlay').classList.remove('hidden');
        document.getElementById('target-msg').innerText = '이동 위치 선택';
    },

    // ============================================
    // [NEW] 연막탄 명령 타겟팅 시작 (특수부대)
    // ============================================
    prepareSmokeCommand() {
        if (!this.selectedUnits || this.selectedUnits.size === 0) {
            ui.showToast('유닛을 먼저 선택하세요');
            return;
        }
        if (this.targetingType) return; // 이미 타겟팅 중

        let hasSpecial = false;
        for (const u of this.selectedUnits) {
            if (u && !u.dead && u.stats?.id === 'special_forces' && (u.smokeChargesLeft || 0) > 0) {
                hasSpecial = true;
                break;
            }
        }
        if (!hasSpecial) {
            ui.showToast('연막탄 사용 가능한 특수부대가 없습니다');
            return;
        }

        this.targetingType = '__smoke__';
        document.getElementById('targeting-overlay').classList.remove('hidden');
        document.getElementById('target-msg').innerText = '연막탄 투척 위치 선택';
    },

    // ============================================
    // [NEW] 이동 명령 처리 (handleTargeting에서 호출)
    // ============================================
    handleMoveTargeting(x) {
        if (!this.selectedUnits || this.selectedUnits.size === 0) return;

        this.selectedUnits.forEach(u => {
            if (!u.dead) {
                u.commandMode = 'move';
                u.targetX = x;
                u.attackTarget = null;
                u.lockedTarget = null;
            }
        });

        ui.showToast(`${this.selectedUnits.size}개 유닛 이동 명령!`);
        this.createParticles(x, this.groundY - 10, 8, '#22c55e');
    },

    // ============================================
    // [NEW] 연막탄 투척 처리 (handleTargeting에서 호출)
    // ============================================
    handleSmokeTargeting(x, y) {
        if (!this.selectedUnits || this.selectedUnits.size === 0) return;

        let usedUnit = null;
        for (const u of this.selectedUnits) {
            if (u && !u.dead && u.stats?.id === 'special_forces' && (u.smokeChargesLeft || 0) > 0) {
                usedUnit = u;
                break;
            }
        }
        if (!usedUnit) {
            ui.showToast('연막탄을 사용할 특수부대가 없습니다');
            return;
        }

        usedUnit.smokeChargesLeft = Math.max(0, (usedUnit.smokeChargesLeft || 0) - 1);
        const ty = Number.isFinite(this.groundY) ? Math.min(y, this.groundY) : y;
        this.spawnSmokeAt(x, ty);
        ui.showToast('연막탄 투척!');
        if (typeof this.updateHUDSelection === 'function') this.updateHUDSelection();
    },

    // ============================================
    // [NEW] 건설 모드 함수
    // 감시탑(watchtower)만 건설 가능, 1회 제한
    // ============================================
    enterBuildMode(buildingType, worker) {
        // [3.8] 감시탑만 건설 가능
        if (buildingType !== 'watchtower') {
            ui.showToast('감시탑만 건설할 수 있습니다!');
            console.warn(`[BUILD] Blocked: ${buildingType} - only watchtower allowed`);
            return;
        }

        // [3.8] 감시탑 1회 건설 제한
        if (this.watchtowerBuilt) {
            ui.showToast('감시탑은 1회만 건설 가능합니다!');
            return;
        }

        if (!CONFIG.constructable[buildingType]) {
            ui.showToast('알 수 없는 건물 타입!');
            return;
        }
        if (this.builderCooldown > 0) {
            ui.showToast('건설 쿨타임 중!');
            return;
        }
        const bData = CONFIG.constructable[buildingType];
        if (this.supply < bData.cost) {
            ui.showToast('자원 부족!');
            return;
        }

        this.buildMode.active = true;
        this.buildMode.type = buildingType;
        this.buildMode.worker = worker;
        this.buildMode.valid = false;

        // 취소 오버레이 표시
        document.getElementById('targeting-overlay').classList.remove('hidden');
        document.getElementById('target-msg').innerText = `${bData.name} 배치 위치 선택`;
    },

    cancelBuildMode() {
        this.buildMode.active = false;
        this.buildMode.type = null;
        this.buildMode.worker = null;
        this.buildMode.valid = false;
        document.getElementById('targeting-overlay').classList.add('hidden');
    },

    updateBuildPreview(worldX, worldY) {
        if (!this.buildMode.active) return;

        const bType = this.buildMode.type;
        const bData = CONFIG.constructable[bType];
        if (!bData) return;

        // 프리뷰 위치 업데이트 (지면에 고정)
        this.buildMode.previewX = worldX;
        this.buildMode.previewY = this.groundY;

        // 배치 가능 여부 판정
        this.buildMode.valid = this.checkBuildPlacement(worldX, bData);
    },

    checkBuildPlacement(x, bData) {
        // 1. 맵 범위 체크
        const halfW = (bData.footprint?.w || bData.width) / 2;
        if (x - halfW < 50 || x + halfW > CONFIG.mapWidth - 50) return false;

        // 2. 기존 건물과 중첩 체크
        for (const b of this.buildings) {
            if (b.dead) continue;
            const bHalfW = (b.width || 100) / 2;
            const dist = Math.abs(b.x - x);
            const minDist = halfW + bHalfW + 20; // 여유 간격
            if (dist < minDist) return false;
        }

        // 3. 건설 중인 건물과도 중첩 체크
        if (this.constructingBuildings) {
            for (const cb of this.constructingBuildings) {
                if (cb.dead) continue;
                const cbHalfW = (cb.width || 100) / 2;
                const dist = Math.abs(cb.x - x);
                const minDist = halfW + cbHalfW + 20;
                if (dist < minDist) return false;
            }
        }

        return true;
    },

    handleBuildPlacement(worldX) {
        if (!this.buildMode.active) return;

        const bType = this.buildMode.type;
        const bData = CONFIG.constructable[bType];
        const worker = this.buildMode.worker;
        if (!bData) return;

        // 유효성 재확인
        if (!this.checkBuildPlacement(worldX, bData)) {
            ui.showToast('이 위치에 건설할 수 없습니다!');
            return;
        }

        // 자원 소모
        if (this.supply < bData.cost) {
            ui.showToast('자원 부족!');
            this.cancelBuildMode();
            return;
        }
        this.supply -= bData.cost;

        // [3.8] 감시탑 건설 1회 제한 플래그 설정
        if (bType === 'watchtower') {
            this.watchtowerBuilt = true;
        }

        // [3.8] 작업자에게 buildTask 생성 (즉시 건설 시작하지 않음)
        if (worker && !worker.dead) {
            worker.buildTask = {
                type: bType,
                x: worldX,
                phase: 'move',     // 'move' → 'build' → done
                started: false,
                buildTime: bData.buildTime
            };
            worker.targetX = worldX;
            ui.showToast('작업자가 이동 중...');
        } else {
            // 작업자가 없거나 죽었으면 즉시 건설 (폴백)
            this.startConstruction(bType, worldX, this.groundY, 'player');
            ui.showToast(`${bData.name} 건설 시작!`);
        }

        // 쿨타임 시작
        this.builderCooldown = bData.cooldown || 120;

        // 건설 모드 종료
        this.cancelBuildMode();

        if (typeof app !== 'undefined') {
            app.markDirty();
            app.markUiDirty();
        }
    },

    // 건설 시작 (Commit C에서 완전 구현)
    startConstruction(bType, x, y, team) {
        // 임시: 바로 완성된 건물 생성 (Commit C에서 건설 중 상태로 변경)
        if (!this.constructingBuildings) this.constructingBuildings = [];

        const bData = CONFIG.constructable[bType];
        const construction = {
            type: bType,
            x: x,
            y: y,
            team: team,
            width: bData.width,
            height: bData.height,
            hp: 1,
            maxHp: bData.hp,
            progress: 0,
            buildTime: bData.buildTime,
            dead: false,
            isConstruction: true,
        };
        this.constructingBuildings.push(construction);
    },

    // [NEW] 건설 프리뷰 렌더링
    drawBuildPreview(ctx) {
        const bType = this.buildMode.type;
        const bData = CONFIG.constructable[bType];
        if (!bData) return;

        const x = this.buildMode.previewX;
        const y = this.groundY;
        const w = bData.width;
        const h = bData.height;

        ctx.save();

        // 유효/무효에 따른 색상
        const isValid = this.buildMode.valid;
        const fillColor = isValid ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)';
        const strokeColor = isValid ? '#22c55e' : '#ef4444';

        // 건물 프리뷰 (반투명)
        ctx.fillStyle = fillColor;
        ctx.fillRect(x - w / 2, y - h, w, h);

        // 테두리 (점선)
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 4]);
        ctx.strokeRect(x - w / 2, y - h, w, h);

        // 건물 이름 표시
        ctx.setLineDash([]);
        ctx.fillStyle = strokeColor;
        ctx.font = 'bold 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(bData.name, x, y - h - 8);

        ctx.restore();
    },

    // [NEW] 건설 진행 업데이트
    updateConstructions() {
        if (!this.constructingBuildings) return;

        const completed = [];

        for (let i = this.constructingBuildings.length - 1; i >= 0; i--) {
            const c = this.constructingBuildings[i];
            if (c.dead) {
                this.constructingBuildings.splice(i, 1);
                continue;
            }

            c.progress++;
            c.hp = Math.floor((c.progress / c.buildTime) * c.maxHp);

            // 건설 완료
            if (c.progress >= c.buildTime) {
                completed.push(c);
                this.constructingBuildings.splice(i, 1);
            }
        }

        // 완료된 건물을 실제 Building으로 변환
        for (const c of completed) {
            this.completeConstruction(c);
        }
    },

    // [NEW] 건설 완료 처리
    completeConstruction(c) {
        const bData = CONFIG.constructable[c.type];
        if (!bData) return;

        // Building 클래스 인스턴스 생성
        const building = new Building(c.type, c.x, c.y, c.team);

        // CONFIG.constructable 데이터로 오버라이드
        building.hp = bData.hp;
        building.maxHp = bData.hp;
        building.width = bData.width;
        building.height = bData.height;
        building.isConstructed = true;  // 플레이어가 건설한 건물 표시

        // 생산 가능 건물인 경우 추가 속성
        if (bData.productionTab) {
            building.productionTab = bData.productionTab;
            building.canProduce = true;
        }

        // 감시탑인 경우 공격 속성 추가
        if (bData.canShoot) {
            building.canShoot = true;
            building.damage = bData.damage;
            building.range = bData.range;
            building.rate = bData.rate;
            building.lastAttack = 0;
        }

        this.buildings.push(building);

        ui.showToast(`${bData.name} 건설 완료!`);

        if (typeof AudioSystem !== 'undefined') {
            AudioSystem.play('build_complete');
        }
    },

    // [NEW] 건설 중인 건물 렌더링 (회색 건설현장 스타일 + 상단 게이지)
    drawConstructingBuilding(ctx, c) {
        const bData = CONFIG.constructable[c.type];
        if (!bData) return;

        const x = c.x, y = c.y, w = c.width, h = c.height;
        const progress = Math.max(0, Math.min(1, c.progress / c.buildTime));
        const pct = Math.floor(progress * 100);

        ctx.save();

        // 1) 건설현장 본체(회색 + 스캐폴드 느낌)
        const left = x - w / 2;
        const top = y - h;

        ctx.fillStyle = '#374151';
        ctx.fillRect(left, top, w, h);

        ctx.strokeStyle = '#9ca3af';
        ctx.lineWidth = 2;
        ctx.strokeRect(left + 2, top + 2, w - 4, h - 4);

        // 세로 기둥
        ctx.globalAlpha = 0.55;
        for (let i = 1; i <= 3; i++) {
            const px = left + (w * i) / 4;
            ctx.beginPath();
            ctx.moveTo(px, top + 6);
            ctx.lineTo(px, y - 6);
            ctx.stroke();
        }

        // 대각 스트라이프(작업중 느낌)
        ctx.globalAlpha = 0.18;
        ctx.strokeStyle = '#e5e7eb';
        ctx.lineWidth = 1;
        const step = 10;
        for (let xx = left - h; xx < left + w + h; xx += step) {
            ctx.beginPath();
            ctx.moveTo(xx, y);
            ctx.lineTo(xx + h, top);
            ctx.stroke();
        }
        ctx.globalAlpha = 1;

        // 2) 상단 작은 게이지 + %
        const barW = Math.max(40, w * 0.78);
        const barH = 7;
        const barX = x - barW / 2;
        const barY = top - 14;

        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.fillRect(barX, barY, barW, barH);
        ctx.fillStyle = '#9ca3af';
        ctx.fillRect(barX, barY, barW * progress, barH);
        ctx.strokeStyle = '#e5e7eb';
        ctx.lineWidth = 1;
        ctx.strokeRect(barX, barY, barW, barH);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`${pct}%`, x, barY - 2);

        // 이름
        ctx.font = 'bold 12px sans-serif';
        ctx.fillStyle = '#e5e7eb';
        ctx.fillText(bData.name, x, barY - 16);

        ctx.restore();
    },

    drawDroneLockTargets(ctx) {
        if (!this.selectedUnits || this.selectedUnits.size === 0) return;
        ctx.save();
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2 / (Camera.zoom || 1);

        this.selectedUnits.forEach(u => {
            if (!u || u.dead || !u.stats) return;
            if (u.stats.operator) return;
            const isDrone = (u.stats.category === 'drone' || (u.stats.id && u.stats.id.includes('drone')));
            if (!isDrone) return;
            const t = u.lockedTarget;
            if (!t || t.dead) return;
            const w = t.width || 32;
            const h = t.height || 32;
            ctx.strokeRect(t.x - w / 2, t.y - h, w, h);
        });

        ctx.restore();
    },

    commandDrones(x, y) {
        let count = 0;
        this.players.forEach(u => {
            if (u.stats.operator) return;
            if (u.stats.category === 'drone' || (u.stats.id && u.stats.id.startsWith('drone'))) {
                if (['drone_suicide', 'drone_at'].includes(u.stats.id)) {
                    u.swarmTarget = { x: x, y: y };
                    u.lockedTarget = null;
                    count++;
                }
            }
        });
        if (count > 0) {
            ui.showToast(`드론 ${count}기 이동 명령!`);
            this.createParticles(x, y, 10, '#facc15');
        }
    },

    createParticles(x, y, count, color) {
        const n = Number(count) || 0;
        if (n <= 0) return;

        // [P0] 화면 밖 파티클 생성 스킵
        if (Number.isFinite(x)) {
            const pad = Number(this.particleCullPadding) || 0;
            const viewW = (typeof Camera !== 'undefined' && Camera.viewW) ? Camera.viewW(this) : this.width;
            const minX = (this.cameraX || 0) - pad;
            const maxX = (this.cameraX || 0) + (viewW || 0) + pad;
            if (x < minX || x > maxX) return;
        }

        // [P0] 프레임당 생성량 캡
        if (this._particleSpawnFrame !== this.frame) {
            this._particleSpawnFrame = this.frame;
            this._particleSpawnCount = 0;
        }
        let remaining = n;
        const perFrameCap = Number(this.particleSpawnCap) || 0;
        if (perFrameCap > 0) {
            const room = perFrameCap - this._particleSpawnCount;
            if (room <= 0) return;
            remaining = Math.min(remaining, room);
        }

        // [P0] 전체 개수 캡
        const totalCap = Number(this.particleCap) || 0;
        if (totalCap > 0) {
            const room = totalCap - this.particles.length;
            if (room <= 0) return;
            remaining = Math.min(remaining, room);
        }

        if (remaining <= 0) return;
        for (let i = 0; i < remaining; i++) this.particles.push(new Particle(x, y, color));
        this._particleSpawnCount += remaining;
    },

    // [NEW] Smoke grenade VFX
    spawnSmokeAt(x, y) {
        if (typeof SmokeCloudFX === 'undefined') return;
        if (!this.particles) return;

        const sx = Number.isFinite(x) ? x : 0;
        const gy = Number.isFinite(this.groundY) ? this.groundY : y;
        const sy = Number.isFinite(y) ? Math.min(y, gy) : gy;

        // 기본 캡 적용
        const totalCap = Number(this.particleCap) || 0;
        if (totalCap > 0 && this.particles.length >= totalCap) return;

        this.particles.push(new SmokeCloudFX(sx, sy));
    },

    // [NEW] Building destruction FX + SFX
    spawnBuildingDestructionFX(b) {
        try {
            const kind = (b && String(b.type || '').includes('hq')) ? 'hq' : 'defense';

            // add FX (rendered in world-space via game.particles pipeline)
            if (typeof BuildingDestructionFX !== 'undefined') {
                this.particles.push(new BuildingDestructionFX(b.x, b.y, b.width, b.height, b.team, kind));
            } else {
                // fallback particles
                this.createParticles(b.x, b.y - (b.height || 80) * 0.5, kind === 'hq' ? 40 : 18, '#111');
                this.createParticles(b.x, b.y - (b.height || 80) * 0.5, kind === 'hq' ? 18 : 8, '#fff');
            }

            // small extra sparks
            this.createParticles(b.x, b.y - (b.height || 80) * 0.5, kind === 'hq' ? 12 : 6, '#facc15');

            // sound - building destruction uses boom-2
            if (typeof AudioSystem !== 'undefined') AudioSystem.playBoom('other');
        } catch (e) {
            console.warn('spawnBuildingDestructionFX failed', e);
        }
    },

    // Queue System
    startHold(key) {
        if (!this.running || this.holdTimer) return;
        // [P0-2] 드론은 단일 클릭으로 즉시 스폰 (hold 반복 안 함)
        if (key === 'drone_suicide' || key === 'drone_at') {
            this.queueUnit(key);
            return;
        }
        this.holdKey = key;
        this.queueUnit(key);
        this.holdTimer = setInterval(() => { this.queueUnit(key); }, 150);
    },

    endHold(key) {
        if (this.holdKey !== key) return;
        if (this.holdTimer) { clearInterval(this.holdTimer); this.holdTimer = null; }
        this.holdKey = null;
    },

    queueUnit(key) {
        const u = CONFIG.units[key];

        // [P0-2] 드론 탭 클릭 = 즉시 출격
        // 드론병이 선택된 상태에서 드론 버튼 클릭 시 즉시 스폰
        if (key === 'drone_suicide' || key === 'drone_at') {
            const operators = this.getDeployableOperators ? this.getDeployableOperators() : [];
            const allOperators = this.getSelectedOperators ? this.getSelectedOperators() : [];

            // 드론병이 선택 안 된 경우
            if (allOperators.length === 0) {
                if (typeof ChatPanel !== 'undefined') {
                    ChatPanel.push('[발진 불가] 드론병 선택 필요', 'WARN');
                }
                return;
            }

            // 드론병은 있지만 발진 가능한 드론병이 없는 경우
            if (operators.length === 0) {
                if (typeof ChatPanel !== 'undefined') {
                    ChatPanel.push('[발진 불가] 드론 충전 없음 또는 이미 드론 운용중', 'WARN');
                }
                return;
            }

            // 발진 가능한 드론병들에게 드론 스폰
            operators.forEach(op => {
                op.commandState = 'stop';
                op.commandMode = 'stop';
                op.attackTarget = null;
            });

            let spawned = 0;
            operators.forEach(op => {
                const drone = this.spawnDroneForOperator ? this.spawnDroneForOperator(op, key) : null;
                if (drone) spawned++;
            });

            if (this.holdTimer) {
                clearInterval(this.holdTimer);
                this.holdTimer = null;
            }
            this.holdKey = null;

            if (typeof ChatPanel !== 'undefined' && spawned > 0) {
                const label = key === 'drone_suicide' ? '자폭드론' : '대전차드론';
                ChatPanel.push(`[발진] ${label} ${spawned}기 즉시 발진`, 'ACTION');
            }
            return;
        }

        // Special logic for targeting
        const needsTargeting = ['tactical_drone', 'stealth_drone', 'blackhawk', 'chinook', 'emp', 'nuke', 'tactical_missile'].includes(key);
        if (needsTargeting) {
            // [FIX] Clear holdTimer value so startHold can run again.
            if (this.holdTimer) {
                clearInterval(this.holdTimer);
                this.holdTimer = null;
            }
            this.holdKey = null;

            this.prepareTargeting(key);
            return;
        }

        if (this.supply >= u.cost && this.playerStock[key] > 0) {
            this.supply -= u.cost;
            this.playerStock[key]--;
            this.spawnQueue[key]++;
            // [FIX] 클릭 즉시 UI 갱신
            if (typeof app !== 'undefined') {
                app.markUiDirty();
                app.commit('queueUnit');
            }
        }
    },

    processQueue() {
        for (let key in this.spawnQueue) {
            if (this.spawnQueue[key] > 0) {
                if (this.cooldowns[key] <= 0) {
                    this.spawnUnitExecution(key);
                    this.spawnQueue[key]--;
                    this.cooldowns[key] = CONFIG.units[key].cooldown;
                }
            }
        }
    },

    spawnUnitDirect(key, x, y, team, bypassBlock = false) {
        // [R 4.2 FIX v3] 구 드론 절대 생성 불가 (하드 가드)
        const OBSOLETE_DRONES = ['tactical_drone', 'stealth_drone'];
        if (OBSOLETE_DRONES.includes(key)) {
            console.warn(`[spawnUnitDirect] HARD BLOCK: ${key} is obsolete`);
            return null;  // 어떤 경우에도 생성 불가
        }

        // 신규 드론은 bypassBlock=true일 때만 생성 가능
        const NEW_DRONES = ['drone_suicide', 'drone_at'];
        if (NEW_DRONES.includes(key) && !bypassBlock) {
            if (team === 'player') {
                if (typeof ChatPanel !== 'undefined') ChatPanel.push(`[차단] ${key}는 직접 생산 불가`, 'WARN');
            }
            console.warn(`[spawnUnitDirect] Blocked: ${key}`);
            return null;
        }

        const unit = new Unit(key, x, y, team);
        if (team === 'player') {
            this.players.push(unit);
            this.playerEverSeen = true;
        } else {
            this.enemies.push(unit);
            this.enemyEverSeen = true;
        }

        // [R 4.2] 생성된 unit 반환 (치명 버그 수정)
        return unit;
    },

    spawnCivilianUnit(key, x, y) {
        const unit = new Unit(key, x, y != null ? y : this.groundY, 'civilian');
        unit.hideHp = true;
        unit.disableFeetSnap = true;
        this.civilians.push(unit);
        return unit;
    },

    spawnCityCivilians() {
        this.civilians = [];
        const spawnDefs = [
            { id: 'civ_sedan', ratio: 0.12 },
            { id: 'civ_suv', ratio: 0.18 },
            { id: 'civ_bus', ratio: 0.26 },
            { id: 'civ_a', ratio: 0.34 },
            { id: 'civ_b', ratio: 0.42 },
            { id: 'civ_crowd', ratio: 0.58 },
            { id: 'civ_sedan', ratio: 0.66 },
            { id: 'civ_suv', ratio: 0.74 },
            { id: 'civ_a', ratio: 0.82 },
            { id: 'civ_b', ratio: 0.9 }
        ];

        const pad = 80;
        spawnDefs.forEach(def => {
            const jitter = (Math.random() * 120 - 60);
            let x = CONFIG.mapWidth * def.ratio + jitter;
            x = Math.max(pad, Math.min(CONFIG.mapWidth - pad, x));
            this.spawnCivilianUnit(def.id, x, this.groundY);
        });

        // [NEW] 중앙 밀집도 강화 (중립 시민 추가 스폰)
        const centerPool = [
            'civ_crowd', 'civ_crowd', 'civ_crowd', 'civ_crowd',
            'civ_a', 'civ_b', 'civ_a', 'civ_b',
            'civ_sedan', 'civ_suv'
        ];
        const centerCount = 8;
        const centerX = CONFIG.mapWidth * 0.5;
        const centerSpread = 220;
        for (let i = 0; i < centerCount; i++) {
            const id = centerPool[Math.floor(Math.random() * centerPool.length)];
            const bias = (Math.random() - Math.random()) * centerSpread;
            let x = centerX + bias;
            x = Math.max(pad, Math.min(CONFIG.mapWidth - pad, x));
            this.spawnCivilianUnit(id, x, this.groundY);
        }
    },

    triggerCivilianPanic(duration = 240) {
        const d = Math.max(60, Number(duration) || 0);
        if (!this.civilians || this.civilians.length === 0) return;
        this.civilians.forEach(c => {
            if (!c || c.dead) return;
            c.panicTimer = Math.max(c.panicTimer || 0, d);
        });
    },

    handleCivilianDeath() {
        this.civilianDeaths = (this.civilianDeaths || 0) + 1;
        if (this.civilianDeaths >= 5 && typeof AudioSystem !== 'undefined' && AudioSystem.stopPanicScream) {
            AudioSystem.stopPanicScream();
        }
        if (this.civilianDeaths >= 2 && !this.airRaidTriggered) {
            this.airRaidTriggered = true;
            if (typeof AudioSystem !== 'undefined') {
                if (AudioSystem.stopBGM) AudioSystem.stopBGM();
                if (AudioSystem.playAirRaidAlarm) AudioSystem.playAirRaidAlarm(14000);
            }
            if (typeof Maps !== 'undefined' && Maps.currentMap === 'city') {
                if (this.airRaidBomberTimeout) {
                    clearTimeout(this.airRaidBomberTimeout);
                }
                this.airRaidBomberTimeout = setTimeout(() => {
                    if (!this.running || this.isGameOver) return;
                    const enemyHQ = this.buildings.find(b => b.type === 'hq_enemy');
                    const spawnX = enemyHQ ? (enemyHQ.x - 50) : (CONFIG.mapWidth - 120);
                    this.spawnUnitDirect('bomber', spawnX, this.groundY, 'enemy');
                }, 30000);
            }
        }
    },

    onAirRaidEnded() {
        if (typeof Maps === 'undefined' || Maps.currentMap !== 'city') return;
        const playerHQ = this.buildings.find(b => b.type === 'hq_player');
        const enemyHQ = this.buildings.find(b => b.type === 'hq_enemy');
        const evacX = playerHQ ? playerHQ.x : (enemyHQ ? enemyHQ.x : 100);
        this.civilianEvacActive = true;
        this.civilianEvacX = evacX;
        if (Array.isArray(this.civilians)) {
            this.civilians.forEach(c => {
                if (!c || c.dead) return;
                c.wanderTargetX = evacX;
                c.wanderTimer = 0;
            });
        }
    },

    spawnEnemy(key) {
        const u = CONFIG.units[key];
        if (this.enemySupply < u.cost || this.enemyCooldowns[key] > 0 || this.enemyStock[key] <= 0) return;
        const hq = this.buildings.find(b => b.type === 'hq_enemy');

        this.enemySupply -= u.cost;
        this.enemyCooldowns[key] = u.cooldown;
        this.enemyStock[key]--;
        const spawnX = hq ? (hq.x - 50) : (CONFIG.mapWidth - 120);
        this.spawnUnitDirect(key, spawnX, this.groundY, 'enemy');
    },

    // [New] Speed Control
    speed: 1,
    // HUD
    minimapVisible: true,

    setSpeed(s) {
        this.speed = s;
        // 즉시 UI 갱신(미니맵 아래 버튼 상태)
        if (typeof ui !== 'undefined') ui.updateSpeedBtns(this.speed);
        // [NEW] Update fixed HUD speed buttons
        if (typeof HUD !== 'undefined') HUD.updateSpeedButtons(this.speed);
    },

    updateZoomUI() {
        const el = document.getElementById('hud-zoom-text');
        if (el) el.textContent = `${Math.round(Camera.zoom * 100)}%`;
        // [NEW] Update fixed HUD zoom display
        if (typeof HUD !== 'undefined') HUD.updateZoomDisplay();
    },

    zoomIn() {
        const wrapper = document.getElementById('game-wrapper');
        if (!wrapper) return;
        const rect = wrapper.getBoundingClientRect();
        const prevZoom = Camera.zoom;
        const newZoom = Camera.zoom + Camera.STEP;
        Camera.applyZoomWithAnchor(this, newZoom, rect.left + rect.width / 2, rect.top + rect.height / 2);
        if (Camera.zoom !== prevZoom) this.updateZoomUI();
    },

    zoomOut() {
        const wrapper = document.getElementById('game-wrapper');
        if (!wrapper) return;
        const rect = wrapper.getBoundingClientRect();
        const prevZoom = Camera.zoom;
        const newZoom = Camera.zoom - Camera.STEP;
        Camera.applyZoomWithAnchor(this, newZoom, rect.left + rect.width / 2, rect.top + rect.height / 2);
        if (Camera.zoom !== prevZoom) this.updateZoomUI();
    },

    // Minimap open/close (deprecated - minimap always visible in new HUD)
    toggleMinimap() {
        // Legacy: kept for compatibility but no longer toggles
        // New HUD always shows minimap
        this.minimapVisible = true;
    },

    // [NEW] Camera lock
    getPrimarySelectedUnit() {
        if (!this.selectedUnits || this.selectedUnits.size === 0) return null;
        for (const u of this.selectedUnits) {
            if (u && !u.dead) return u;
        }
        return null;
    },

    isCameraLocked() {
        return !!this.cameraLockActive;
    },

    toggleCameraLock() {
        if (this.cameraLockActive) {
            this.cameraLockActive = false;
            this.cameraLockTarget = null;
            return;
        }

        const target = this.getPrimarySelectedUnit();
        if (!target) {
            if (typeof ui !== 'undefined' && typeof ui.showToast === 'function') {
                ui.showToast('유닛을 먼저 선택하세요');
            }
            return;
        }

        this.cameraLockActive = true;
        this.cameraLockTarget = target;
    },

    applyCameraLock() {
        if (!this.cameraLockActive) return;

        let target = this.cameraLockTarget;
        if (!target || target.dead) {
            target = this.getPrimarySelectedUnit();
            this.cameraLockTarget = target;
        } else if (this.selectedUnits && this.selectedUnits.size > 0 && !this.selectedUnits.has(target)) {
            const nextTarget = this.getPrimarySelectedUnit();
            if (nextTarget) this.cameraLockTarget = nextTarget;
            target = this.cameraLockTarget;
        }

        if (!target) {
            this.cameraLockActive = false;
            return;
        }

        const viewW = (typeof Camera !== 'undefined' && Camera.viewW) ? Camera.viewW(this) : this.width;
        this.cameraX = (target.x || 0) - viewW / 2;
        if (typeof Camera !== 'undefined' && Camera.clampCameraX) {
            this.cameraX = Camera.clampCameraX(this, this.cameraX);
        } else {
            this.cameraX = Math.max(0, Math.min(this.cameraX, CONFIG.mapWidth - this.width));
        }
    },

    loop() {
        if (!this.running) return;

        // [New] Speed Logic
        // 1x: Update once
        // 2x: Update twice
        // 0.5x: Update every other frame

        // [FIX] Use engineFrame to prevent freeze (game.frame only updates inside this.update)
        this.engineFrame = (this.engineFrame || 0) + 1;

        let updates = 1;
        if (this.speed === 2) updates = 2;
        else if (this.speed === 0.5 && this.engineFrame % 2 !== 0) updates = 0;

        try {
            for (let i = 0; i < updates; i++) {
                this.update();
            }
            if (updates > 0) this.draw();
        } catch (e) {
            console.error("Game Loop Error (Recovered):", e);
        }

        this.loopId = requestAnimationFrame(() => this.loop());
    },

    update() {
        if (this.isGameOver) return;
        this.frame++; // Always increment frame internally? No, frame should track logic ticks.
        // Actually, if we skip update, frame doesn't increment.
        // If we double update, frame increments twice.
        // This is correct for game logic time.

        // [NEW] Update Timer UI (once per second)
        if (this.$hudTimer) {
            const t = Math.floor(this.frame / 60);
            const min = Math.floor(t / 60).toString().padStart(2, '0');
            const sec = (t % 60).toString().padStart(2, '0');
            const text = `${min}:${sec}`;
            if (text !== this._lastTimerText) {
                this._lastTimerText = text;
                this.$hudTimer.textContent = text;
            }
        }

        if (this.supply < CONFIG.maxSupply) this.supply += CONFIG.supplyRate;
        if (this.enemySupply < CONFIG.maxSupply) this.enemySupply += CONFIG.supplyRate;

        this.processQueue();

        for (let k in this.cooldowns) if (this.cooldowns[k] > 0) this.cooldowns[k]--;
        for (let k in this.enemyCooldowns) if (this.enemyCooldowns[k] > 0) this.enemyCooldowns[k]--;

        // [NEW] 작업자 건설 쿨타임 감소
        if (this.builderCooldown > 0) this.builderCooldown--;

        if (this.empTimer > 0) {
            this.empTimer--;
            // [P0-4] 상태 변화 시에만 class 토글 (DOM 쿼리 캐싱)
            const shouldBeActive = this.empTimer > 0;
            if (this._empWasActive !== shouldBeActive && this.$empFlash) {
                this.$empFlash.classList.toggle('active', shouldBeActive);
                this._empWasActive = shouldBeActive;
            }
        } else if (this._empWasActive && this.$empFlash) {
            this.$empFlash.classList.remove('active');
            this._empWasActive = false;
        }

        // [P0-2] 단일 패스: dead 제거 + player/enemy 분류 + HQ 탐색
        this.playerBuildings.length = 0;
        this.enemyBuildings.length = 0;
        let playerHQ = null;
        let enemyHQ = null;
        let writeIdx = 0;
        for (let i = 0; i < this.buildings.length; i++) {
            const b = this.buildings[i];
            if (!b.dead) {
                this.buildings[writeIdx++] = b;
                if (b.team === 'player') {
                    this.playerBuildings.push(b);
                    if (b.type === 'hq_player') playerHQ = b;
                } else if (b.team === 'enemy') {
                    this.enemyBuildings.push(b);
                    if (b.type === 'hq_enemy') enemyHQ = b;
                }
            }
        }
        this.buildings.length = writeIdx;

        // [NEW] 맵별 승리 조건 체크
        const winCondition = (typeof Maps !== 'undefined') ? Maps.getRule('winCondition') : 'hq_destroy';
        const survivalTime = (typeof Maps !== 'undefined') ? Maps.getRule('survivalTime') : 600;
        const elapsedSeconds = this.frame / 60; // 60 FPS 기준

        // [NEW] 도시맵 9분 경과 시 총공세 발동
        if (typeof Maps !== 'undefined' && Maps.currentMap === 'city') {
            if (!this.totalWarTriggered && elapsedSeconds >= 540) {
                this.triggerTotalWar();
                if (typeof AI !== 'undefined') AI._totalWarIssued = true;
            }
        }

        // 생존한 유닛 수 계산
        const alivePlayerUnits = this.players.filter(u => !u.dead).length;
        const aliveEnemyUnits = this.enemies.filter(u => !u.dead).length;
        if (alivePlayerUnits > 0) this.playerEverSeen = true;
        if (aliveEnemyUnits > 0) this.enemyEverSeen = true;

        // [CITY] 1분 경과 + 아군 기갑 1기 이상(HQ 근처) -> 긴급속보 뉴스
        if (typeof Maps !== 'undefined' && Maps.currentMap === 'city' && !this.cityArmorNewsShown) {
            const playerHQForNews = playerHQ;
            const armoredNearHQ = this.players.some(u => {
                if (!u || u.dead || !u.stats || u.stats.category !== 'armored') return false;
                if (!playerHQForNews) return true;
                return Math.abs(u.x - playerHQForNews.x) <= 320;
            });
            if (elapsedSeconds >= 60 && armoredNearHQ) {
                this.cityArmorNewsShown = true;
                if (playerHQForNews) {
                    this.newsCameraX = playerHQForNews.x;
                }

                const showOverlay = () => {
                    const preset = (typeof NEWS_TEXTS !== 'undefined' && NEWS_TEXTS.cityArmor)
                        ? NEWS_TEXTS.cityArmor
                        : {
                            lockLocation: true,
                            location: '수도권 외곽 순환도로 상공 | 17:45',
                            title: '긴급속보',
                            headline: '[속보] 원블루국 국군, 시가지 진입 개시 첫 교차로 확보',
                            ticker: '수도권 상공 헬기 편대 진입... 긴장 고조   ///   군 당국 \"시민 안전 위해 작전 지역 접근 금지\"   ///   통신망 일부 장애 발생... 복구 작업 중   ///   야간 통행 금지령 검토 중'
                        };
                    NewsOverlay.setCustomText(preset);
                    NewsOverlay.show(9000);
                    setTimeout(() => {
                        if (typeof NewsOverlay !== 'undefined' && NewsOverlay.clearCustomText) {
                            NewsOverlay.clearCustomText();
                        }
                        this.newsCameraX = null;
                    }, 9400);
                };

                if (typeof NewsOverlay !== 'undefined' && NewsOverlay.setCustomText) {
                    if (typeof NewsIntro !== 'undefined' && NewsIntro.show) {
                        NewsIntro.show(3000, showOverlay);
                    } else {
                        showOverlay();
                    }
                }
            }
        }

        // [CITY] 2분 30초 경과 -> 3번째 뉴스 (오른쪽 거점 고정)
        if (typeof Maps !== 'undefined' && Maps.currentMap === 'city' && !this.cityMidNewsShown) {
            if (elapsedSeconds >= 150) {
                this.cityMidNewsShown = true;

                const rightBunker = this.buildings
                    .filter(b => b && !b.dead && b.type === 'bunker')
                    .sort((a, b) => b.x - a.x)[0];
                if (rightBunker) {
                    this.newsCameraX = rightBunker.x;
                }

                const showOverlay = () => {
                    const preset = (typeof NEWS_TEXTS !== 'undefined' && NEWS_TEXTS.cityMid)
                        ? NEWS_TEXTS.cityMid
                        : {
                            lockLocation: true,
                            location: '원블루국 도심 | 17:58',
                            title: '긴급속보',
                            headline: '붉은네모국 대통령',
                            ticker: '원블루국 도심, 적 병력 대거 유입... 피해 급증   ///   적군 공세 강화... 외곽 방어선 곳곳에서 교전   ///   도심 진입로로 적 병력 유입 확인... 긴급 대피 권고   ///   사상자 증가... 구급 출동 지연, 의료 대응 한계'
                        };
                    NewsOverlay.setCustomText(preset);
                    NewsOverlay.show(9000);
                    setTimeout(() => {
                        if (typeof NewsOverlay !== 'undefined' && NewsOverlay.clearCustomText) {
                            NewsOverlay.clearCustomText();
                        }
                        this.newsCameraX = null;
                    }, 9400);
                };

                if (typeof NewsOverlay !== 'undefined' && NewsOverlay.setCustomText) {
                    if (typeof NewsIntro !== 'undefined' && NewsIntro.show) {
                        NewsIntro.show(3000, showOverlay);
                    } else {
                        showOverlay();
                    }
                }
            }
        }

        // [CITY] 9분 경과 -> 4번째 뉴스 (오른쪽 거점 고정)
        if (typeof Maps !== 'undefined' && Maps.currentMap === 'city' && !this.cityTotalWarNewsShown) {
            if (elapsedSeconds >= 540) {
                this.cityTotalWarNewsShown = true;

                // 오른쪽 거점(벙커) 기준 카메라
                const rightBunker = this.buildings
                    .filter(b => b && !b.dead && b.type === 'bunker')
                    .sort((a, b) => b.x - a.x)[0];
                if (rightBunker) {
                    this.newsCameraX = rightBunker.x;
                }

                const showOverlay = () => {
                    const preset = (typeof NEWS_TEXTS !== 'undefined' && NEWS_TEXTS.cityTotalWar)
                        ? NEWS_TEXTS.cityTotalWar
                        : {
                            lockLocation: true,
                            location: '도시 외곽 방어선 | 18:09',
                            title: '긴급속보',
                            headline: '붉은네모국 대통령 총력전 선포',
                            ticker: '[속보] 전면 총력전 돌입 선언   ///   국방부 \"모든 예비전력 즉시 동원\"   ///   도심 통제 구역 확대   ///   시민 대피령 강화'
                        };
                    NewsOverlay.setCustomText(preset);
                    NewsOverlay.show(9000);
                    setTimeout(() => {
                        if (typeof NewsOverlay !== 'undefined' && NewsOverlay.clearCustomText) {
                            NewsOverlay.clearCustomText();
                        }
                        this.newsCameraX = null;
                    }, 9400);
                };

                if (typeof NewsOverlay !== 'undefined' && NewsOverlay.setCustomText) {
                    if (typeof NewsIntro !== 'undefined' && NewsIntro.show) {
                        NewsIntro.show(3000, showOverlay);
                    } else {
                        showOverlay();
                    }
                }
            }
        }

        if (winCondition === 'hq_destroy' || winCondition === 'survival' || winCondition === 'annihilation') {
            const canCheck = this.frame > 180; // 초반 3초간은 승리/패배 조건 체크 안 함
            const playerHasHQ = !!playerHQ;
            const playerWiped = this.playerEverSeen && alivePlayerUnits === 0;
            const enemyWiped = this.enemyEverSeen && aliveEnemyUnits === 0;
            const survived = elapsedSeconds >= survivalTime;

            if (canCheck) {
                if (enemyWiped) {
                    this.endGame('win', '작전 성공', '적군을 모두 섬멸했습니다.');
                } else if (survived) {
                    this.endGame('win', '작전 성공', `${Math.floor(survivalTime / 60)}분간 방어에 성공했습니다.`);
                } else if (!playerHasHQ && playerWiped) {
                    this.endGame('lose', '작전 실패', '아군이 전멸했습니다.');
                }
            }
        }
        if (this.isGameOver) return;

        this.players.forEach(u => u.update(this.enemies, this.enemyBuildings));
        this.enemies.forEach(u => u.update(this.players, this.playerBuildings));
        this.civilians.forEach(u => u.update(this.enemies, this.enemyBuildings));
        this.buildings.forEach(b => b.update(this.enemies, this.players));
        this.projectiles.forEach(p => p.update());
        this.particles.forEach(p => p.update());

        // [NEW] 건설 중인 건물 업데이트
        this.updateConstructions();

        // [NEW] Camera lock follow
        this.applyCameraLock();

        // [P0-1] In-place compaction (GC 할당 제거)
        compactArray(this.players, u => !u.dead);
        compactArray(this.enemies, u => !u.dead);
        compactArray(this.civilians, u => !u.dead);
        compactArray(this.projectiles, p => !p.dead);
        compactArray(this.particles, p => p.life > 0);

        // [VFX] decay
        if (this.shake > 0.01) {
            this.shake *= this.shakeDecay;
            if (this.shake < 0.15) this.shake = 0;
        } else {
            this.shake = 0;
        }
        if (this.flash > 0.01) {
            this.flash *= this.flashDecay;
            if (this.flash < 0.02) this.flash = 0;
        } else {
            this.flash = 0;
        }

        if (typeof AI !== 'undefined') AI.update(this.frame);

        // [FIX] 쿨타임/큐가 진행 중이면 매 프레임 UI 갱신 필요
        if (typeof app !== 'undefined') {
            // 쿨타임이 진행 중이거나 큐가 있으면 uiDirty
            const hasCooldown = Object.values(this.cooldowns).some(v => v > 0);
            const hasQueue = Object.values(this.spawnQueue).some(v => v > 0);
            if (hasCooldown || hasQueue) {
                app.markUiDirty();
            }
        }

        if (this.frame % 5 === 0) {
            this.renderUI();
        }

        const mmInterval = Number.isFinite(this.minimapInterval) ? this.minimapInterval : 8;
        if (mmInterval > 0 && this.frame % mmInterval === 0) {
            // [NEW] Draw minimap on fixed HUD
            if (typeof HUD !== 'undefined') {
                HUD.drawMinimap();
            }
            // Legacy minimap only when modal is visible
            const mapModal = document.getElementById('map-modal');
            if (mapModal && !mapModal.classList.contains('hidden')) {
                this.drawHUDMinimap();
            }
        }
    },

    renderUI() {
        // [CHANGE][APP] UI 갱신 경로 단일화
        // - 기존: ui.updateUnitButtons(), ui.setSkillCount() ... 분산 호출
        // - 변경: app.commit() 한 번에서만 UI + 저장 처리
        if (typeof app !== 'undefined') app.commit('tick');
    },

    draw() {
        const ctx = this.ctx;
        // [FIX][ZOOM-ARTIFACT] always clear whole screen in screen-space
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, this.width, this.height);
        ctx.fillStyle = '#bae6fd';
        ctx.fillRect(0, 0, this.width, this.height);

        if (typeof Maps !== 'undefined') {
            // 1) Base sky/ground stays in screen space
            Maps.drawBase(ctx, this.width, this.height, this.groundY);

            // 2) Decorations draw in zoomed world space
            ctx.save();
            ctx.translate(0, this.groundY);
            ctx.scale(Camera.zoom, Camera.zoom);
            ctx.translate(0, -this.groundY);

            Maps.drawDecorations(
                ctx,
                this.width / Camera.zoom,
                this.height / Camera.zoom,
                this.groundY,
                this.cameraX
            );

            ctx.restore();
        }

        ctx.save();
        ctx.translate(0, this.groundY);
        ctx.scale(Camera.zoom, Camera.zoom);
        ctx.translate(0, -this.groundY);
        ctx.translate(-Math.floor(this.cameraX), 0);

        // [VFX] world-layer shake (screen 기준 고정)
        if (this.shake > 0.01) {
            const j = this.shake / Math.max(0.01, Camera.zoom);
            ctx.translate((Math.random() - 0.5) * j * 2, (Math.random() - 0.5) * j * 2);
        }
        this.buildings.forEach(b => b.draw(ctx));

        this.civilians.forEach(u => u.draw(ctx));

        // [FIX] 건설 진행 UI는 유닛보다 뒤(배경 레이어)에 렌더링
        if (this.constructingBuildings) {
            this.constructingBuildings.forEach(c => {
                if (c.dead) return;
                this.drawConstructingBuilding(ctx, c);
            });
        }

        this.enemies.forEach(u => u.draw(ctx));
        this.players.forEach(u => u.draw(ctx));
        this.projectiles.forEach(p => p.draw(ctx));
        this.particles.forEach(p => p.draw(ctx));

        // [NEW] 건설 프리뷰 렌더링
        if (this.buildMode.active && this.buildMode.type) {
            this.drawBuildPreview(ctx);
        }

        this.drawDroneLockTargets(ctx);

        ctx.restore();

        // [VFX] screen flash (screen-space) - 흰색만 사용
        if (this.flash > 0.01) {
            ctx.save();
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.fillStyle = `rgba(255,255,255,${this.flash})`;
            ctx.fillRect(0, 0, this.width, this.height);
            ctx.restore();
        }

        if (typeof NewsOverlay !== 'undefined') {
            NewsOverlay.renderFromGame(this);
        }

    },

    toggleScope() {
        const modal = document.getElementById('scope-modal');
        modal.classList.toggle('hidden');
        ui.updateEnemyStatus(this.enemyStock);
    },

    toggleMap() {
        // Replaced by HUD
    },

    drawHUD() {
        const ctx = this.ctx;
        // 모바일 가로 모드인지 체크
        const isMobileLandscape = window.innerHeight < 600 && window.innerWidth > window.innerHeight;

        const fontSize = (this.width < 800) ? 16 : 24;
        const padding = (this.width < 800) ? 10 : 20;

        ctx.save();
        ctx.font = `bold ${fontSize}px "Orbitron", sans-serif`;
        ctx.textBaseline = 'top';
        ctx.shadowColor = 'black';
        ctx.shadowBlur = 4;

        // [변경] 자원(SUPPLY) 표시 위치
        // 모바일 가로 모드면 -> 왼쪽 하단 (Bottom Left)
        // 그 외(PC/세로) -> 왼쪽 상단 (Top Left)
        let supplyX = padding;
        let supplyY = padding;

        if (isMobileLandscape) {
            supplyX = padding;
            supplyY = this.height - padding - 40; // 바닥에서 조금 위
        }

        // 1. Supply Text
        ctx.fillStyle = '#fbbf24';
        ctx.textAlign = 'left';
        ctx.fillText(`SUPPLY: ${Math.floor(this.supply)}`, supplyX, supplyY);

        // Supply Bar (Text 아래에)
        const barW = (this.width < 800) ? 100 : 150;
        const barH = (this.width < 800) ? 4 : 6;
        const ratio = Math.min(1, this.supply / CONFIG.maxSupply);

        ctx.fillStyle = '#4b5563';
        ctx.fillRect(supplyX, supplyY + fontSize + 5, barW, barH);
        ctx.fillStyle = '#fbbf24';
        ctx.fillRect(supplyX, supplyY + fontSize + 5, barW * ratio, barH);

        // 2. Kill Count (오른쪽 상단 유지)
        ctx.textAlign = 'right';
        ctx.fillStyle = '#ef4444';
        ctx.fillText(`KILLS: ${this.killCount || 0}`, this.width - padding, padding);

        // 3. Time (중앙 상단 유지)
        ctx.textAlign = 'center';
        ctx.fillStyle = 'white';
        const time = Math.floor(this.frame / 60);
        const min = Math.floor(time / 60).toString().padStart(2, '0');
        const sec = (time % 60).toString().padStart(2, '0');
        ctx.fillText(`${min}:${sec}`, this.width / 2, padding);

        // [NEW] 공습경보 표시
        if (this.airRaidWarning) {
            const warn = this.airRaidWarning;
            const elapsed = (this.frame || 0) - warn.startFrame;
            const total = warn.endFrame - warn.startFrame;
            const progress = Math.min(1, elapsed / total);

            // 깜빡임 효과
            const blink = Math.floor(elapsed / 8) % 2 === 0;

            if (blink) {
                const warnFontSize = (this.width < 800) ? 28 : 48;
                ctx.font = `bold ${warnFontSize}px "Orbitron", sans-serif`;
                ctx.textAlign = 'left';

                // 빨간색 그라데이션 효과
                ctx.fillStyle = '#ef4444';
                ctx.shadowColor = '#ff0000';
                ctx.shadowBlur = 20;

                // 왼쪽 중앙에 표시
                const warnX = padding + 10;
                const warnY = this.height / 2 - warnFontSize;

                ctx.fillText('공습경보', warnX, warnY);

                // 무기 종류 표시
                const subFontSize = (this.width < 800) ? 16 : 24;
                ctx.font = `bold ${subFontSize}px "Orbitron", sans-serif`;
                ctx.fillStyle = '#fbbf24';
                const weaponName = warn.type === 'nuke' ? '전술핵 발사 감지!' : '전술미사일 발사 감지!';
                ctx.fillText(weaponName, warnX, warnY + warnFontSize + 10);

                // 남은 시간 바 표시
                const barWidth = 150;
                const barHeight = 8;
                ctx.fillStyle = '#4b5563';
                ctx.fillRect(warnX, warnY + warnFontSize + subFontSize + 20, barWidth, barHeight);
                ctx.fillStyle = '#ef4444';
                ctx.fillRect(warnX, warnY + warnFontSize + subFontSize + 20, barWidth * (1 - progress), barHeight);
            }
        }

        ctx.restore();
    },

    drawHUDMinimap() {
        const cvs = document.getElementById('hud-minimap');
        if (!cvs) return;
        const ctx = cvs.getContext('2d');
        if (cvs.width !== cvs.clientWidth) { cvs.width = cvs.clientWidth; cvs.height = cvs.clientHeight; }

        ctx.fillStyle = '#0f172a'; ctx.fillRect(0, 0, cvs.width, cvs.height);
        const scale = cvs.width / CONFIG.mapWidth;
        const groundY = cvs.height * 0.7;

        ctx.strokeStyle = '#334155'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, groundY); ctx.lineTo(cvs.width, groundY); ctx.stroke();

        this.buildings.forEach(b => {
            ctx.fillStyle = b.team === 'player' ? '#3b82f6' : (b.team === 'enemy' ? '#ef4444' : '#eab308');
            const w = Math.max(2, b.width * scale);
            const h = Math.max(2, b.height * scale);
            ctx.fillRect(b.x * scale - w / 2, groundY - h, w, h);
        });

        ctx.fillStyle = '#60a5fa'; this.players.forEach(u => ctx.fillRect(u.x * scale, groundY - 2, 2, 2));
        ctx.fillStyle = '#f87171'; this.enemies.forEach(u => ctx.fillRect(u.x * scale, groundY - 2, 2, 2));

        const cw = (Camera.viewW(this) / CONFIG.mapWidth) * cvs.width;
        const cx = (this.cameraX / CONFIG.mapWidth) * cvs.width;
        ctx.strokeStyle = '#fbbf24'; ctx.lineWidth = 1; ctx.strokeRect(cx, 0, cw, cvs.height);
    },

    // [FIX] 메모리 누수 방지 - 게임 종료 시 타이머 정리
    _cleanupTimers() {
        // AI 타이머 정리
        if (typeof AI !== 'undefined') {
            if (AI._nukeWarningTimeout) { clearTimeout(AI._nukeWarningTimeout); AI._nukeWarningTimeout = null; }
            if (AI._tacticalWarningTimeout) { clearTimeout(AI._tacticalWarningTimeout); AI._tacticalWarningTimeout = null; }
        }
        // 폭격기 에어레이드 타이머 정리
        if (this.airRaidBomberTimeout) { clearTimeout(this.airRaidBomberTimeout); this.airRaidBomberTimeout = null; }
        // 미니맵 인터벌 정리
        if (this._minimapInterval) { clearInterval(this._minimapInterval); this._minimapInterval = null; }
        // 유닛 생산 홀드 타이머 정리
        if (this.holdTimer) { clearInterval(this.holdTimer); this.holdTimer = null; }
        // 뉴스 타이머 정리
        if (typeof NewsOverlay !== 'undefined') {
            if (NewsOverlay._showTimer) { clearTimeout(NewsOverlay._showTimer); NewsOverlay._showTimer = null; }
            if (NewsOverlay._hideTimer) { clearTimeout(NewsOverlay._hideTimer); NewsOverlay._hideTimer = null; }
        }
        if (typeof NewsIntro !== 'undefined' && NewsIntro._timer) {
            clearTimeout(NewsIntro._timer); NewsIntro._timer = null;
        }
    },

    endGame(result, title, desc) {
        if (this.isGameOver) return;
        this.isGameOver = true;

        // [FIX] 메모리 누수 방지 - 타이머 정리
        this._cleanupTimers();

        if (result === 'win') {
            if (typeof Maps !== 'undefined' && Maps.currentMap) {
                this.markMapCleared(Maps.currentMap);
            }
        }

        // [NEW] 게임 오버(승/패 무관)에도 난이도/맵 진행도 저장
        if (typeof app !== 'undefined' && app.saveNow) {
            app.saveNow();
        }

        // [R 4.2] 작전실패 시 하단 유닛생성바 숨김
        this.cancelTargeting();
        document.getElementById('unit-panel-container')?.classList.add('hidden');
        document.getElementById('hud-footer')?.classList.add('hidden');
        if (typeof HUD !== 'undefined') HUD.hide();
        if (typeof NewsIntro !== 'undefined') NewsIntro.hide();
        if (typeof NewsOverlay !== 'undefined') NewsOverlay.hide();

        const s = document.getElementById('end-screen');
        s.classList.remove('hidden'); s.style.display = 'flex';
        document.getElementById('end-title').innerText = title;
        document.getElementById('end-title').className = `text-5xl font-bold mb-4 ${result === 'win' ? 'text-blue-500' : 'text-red-500'}`;
        document.getElementById('end-desc').innerText = desc;
    },

    // ================================
    // [NEW] 임무 목표 시스템
    // ================================
    _updateMissionObjectiveText() {
        if (!this.$missionText) return;
        const map = (typeof Maps !== 'undefined' && Maps.currentMap) ? Maps.currentMap : 'plain';
        const survivalTime = (typeof Maps !== 'undefined') ? Maps.getRule('survivalTime') : 600;
        const totalSeconds = Number.isFinite(survivalTime) ? survivalTime : 600;
        const min = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
        const sec = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
        const survivalLabel = `${min}:${sec}`;
        let text = '';
        switch (map) {
            case 'city':
                text = `${survivalLabel}까지 버티거나 적을 모두 섬멸하세요.`;
                break;
            case 'plain':
            case 'mountain':
                text = `${survivalLabel}까지 버티거나 적을 모두 섬멸하세요.`;
                break;
            case 'village':
                text = `${survivalLabel}까지 버티거나 적을 모두 섬멸하세요.`;
                break;
            default:
                text = '작전을 성공적으로 완수하세요.';
        }
        this.$missionText.textContent = text;
    },

    showMissionObjective() {
        if (this.$missionModal) {
            this.$missionModal.classList.remove('hidden');
        }
    },

    hideMissionObjective() {
        if (this.$missionModal) {
            this.$missionModal.classList.add('hidden');
        }
    }
};

// ================================
// [ADD][APP] Minimal App Layer
// - commit() = 단일 갱신(저장 + UI)
// - migrate() = 스키마 고정 + 자동 보정
// - API = 앞으로 상태 변경은 app.* 로만 통과시키는 "확증형 슬롯"
// ================================
const app = {
    STORAGE_KEY: 'CT_STATE_V1',
    BACKUP_KEY_1: 'CT_STATE_V1_BAK1',
    BACKUP_KEY_2: 'CT_STATE_V1_BAK2',
    SCHEMA_VERSION: 1,

    _dirty: true,
    _uiDirty: true,
    _lastSaveAt: 0,

    // ---- (1) 스냅샷 생성 (최소: 설정/통계만) ----
    _makeState() {
        const diff = (typeof AI !== 'undefined' && AI.difficulty) ? AI.difficulty : 'veteran';
        // lastMapId는 현재 코드에 "선택한 맵 id" 변수가 있으면 연결하고, 없으면 null
        const lastMapId = game.currentMapId || null;

        return {
            version: this.SCHEMA_VERSION,
            settings: {
                speed: Number(game.speed) || 1,
                difficulty: String(diff || 'veteran'),
                lastMapId: lastMapId ? String(lastMapId) : null,
            },
            stats: {
                killCount: Number(game.killCount) || 0,
            },
            progress: {
                clearedMaps: Array.isArray(game.clearedMaps) ? game.clearedMaps : [],
                firstRunDone: !!game.firstRunDone
            }
        };
    },

    // ---- (2) 마이그레이션(자동 보정) ----
    migrate(raw) {
        // raw가 null/undefined면 새로 생성
        if (!raw || typeof raw !== 'object') raw = { version: 0 };

        const v = Number(raw.version) || 0;

        // v0 -> v1 보정
        if (v < 1) {
            raw.version = 1;
            raw.settings = raw.settings || {};
            raw.stats = raw.stats || {};
        }

        // 타입/누락 보정
        if (!raw.settings || typeof raw.settings !== 'object') raw.settings = {};
        if (!raw.stats || typeof raw.stats !== 'object') raw.stats = {};
        if (!raw.progress || typeof raw.progress !== 'object') raw.progress = {};

        const sp = Number(raw.settings.speed);
        raw.settings.speed = Number.isFinite(sp) ? sp : 1;

        raw.settings.difficulty = (typeof raw.settings.difficulty === 'string' && raw.settings.difficulty)
            ? raw.settings.difficulty
            : 'veteran';

        raw.settings.lastMapId = (raw.settings.lastMapId == null)
            ? null
            : String(raw.settings.lastMapId);

        const kc = Number(raw.stats.killCount);
        raw.stats.killCount = Number.isFinite(kc) ? kc : 0;

        if (!Array.isArray(raw.progress.clearedMaps)) raw.progress.clearedMaps = [];
        if (typeof raw.progress.firstRunDone !== 'boolean') {
            raw.progress.firstRunDone = raw.progress.clearedMaps.length > 0;
        }

        raw.version = 1;
        return raw;
    },

    // ---- (3) 로드/세이브 ----
    load() {
        const tryParse = (key) => {
            try {
                const s = localStorage.getItem(key);
                if (!s) return null;
                const parsed = JSON.parse(s);
                if (parsed && typeof parsed === 'object') return parsed;
            } catch (e) { }
            return null;
        };

        // 1. 메인 저장 시도
        let data = tryParse(this.STORAGE_KEY);
        if (data) return this.migrate(data);

        // 2. BAK1 복구 시도
        data = tryParse(this.BACKUP_KEY_1);
        if (data) {
            console.warn('[APP] Main save corrupted, restored from BAK1');
            return this.migrate(data);
        }

        // 3. BAK2 복구 시도
        data = tryParse(this.BACKUP_KEY_2);
        if (data) {
            console.warn('[APP] Main save corrupted, restored from BAK2');
            return this.migrate(data);
        }

        // 4. 전부 실패 → 초기화
        return this.migrate(null);
    },

    saveNow() {
        try {
            // 롤링 백업: 현재 BAK1 → BAK2로, 현재 STATE → BAK1으로
            const currentBak1 = localStorage.getItem(this.BACKUP_KEY_1);
            if (currentBak1) {
                localStorage.setItem(this.BACKUP_KEY_2, currentBak1);
            }
            const currentState = localStorage.getItem(this.STORAGE_KEY);
            if (currentState) {
                localStorage.setItem(this.BACKUP_KEY_1, currentState);
            }

            // 새 상태 저장
            const state = this._makeState();
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(state));
            this._lastSaveAt = performance.now ? performance.now() : Date.now();
        } catch (e) {
            // localStorage 불가 환경이면 조용히 무시
        }
    },

    // ---- (4) 게임에 적용(최소: speed/difficulty/lastMapId) ----
    loadIntoGame() {
        const st = this.load();

        // speed 적용
        if (st.settings && Number.isFinite(st.settings.speed)) {
            game.setSpeed(st.settings.speed); // 내부에서 ui 버튼도 갱신됨
        }

        // difficulty는 AI가 가지고 있으면 반영
        if (typeof AI !== 'undefined' && st.settings && typeof st.settings.difficulty === 'string') {
            AI.difficulty = st.settings.difficulty;
        }

        // lastMapId(있으면) 보관만 해둠 (현재 코드에서 map선택 로직이 있으면 연결 가능)
        if (st.settings && st.settings.lastMapId) {
            game.currentMapId = st.settings.lastMapId;
        }

        if (st.progress && Array.isArray(st.progress.clearedMaps)) {
            game.clearedMaps = st.progress.clearedMaps.slice(0);
        }
        game.firstRunDone = !!(st.progress && st.progress.firstRunDone);

        this._dirty = true;
    },

    // ---- (5) Dirty + 단일 갱신(commit) ----
    markDirty() { this._dirty = true; },
    markUiDirty() { this._uiDirty = true; },

    commit(reason = '') {
        const wasDirty = this._dirty;
        const wasUiDirty = this._uiDirty;
        this._dirty = false;
        this._uiDirty = false;

        // UI 갱신은 uiDirty일 때만
        if (wasUiDirty) {
            ui.updateCategoryTab(game.currentCategory);
            ui.updateUnitButtons(game.currentCategory, game.playerStock, game.cooldowns, game.supply, game.spawnQueue);
            ui.setSkillCount('emp', game.skillCharges.emp);
            ui.setSkillCount('nuke', game.skillCharges.nuke);
            ui.updateSpeedBtns(game.speed);
        }

        if (!wasDirty) return;

        // Save state at most once per second
        const now = performance.now ? performance.now() : Date.now();
        if (now - this._lastSaveAt > 1000) this.saveNow();
    },

    // ---- (6) 확증형 슬롯(App API) 최소 제공 ----
    setSpeed(s) {
        game.setSpeed(s);
        this.markDirty();
        this.markUiDirty();
    },
    addSupply(n) {
        const v = Number(n) || 0;
        game.supply = Math.max(0, (Number(game.supply) || 0) + v);
        this.markDirty();
        this.markUiDirty();
    },
    spendSupply(n) {
        const v = Number(n) || 0;
        game.supply = Math.max(0, (Number(game.supply) || 0) - v);
        this.markDirty();
        this.markUiDirty();
    },
    spawnUnitDirect(key, x, team) {
        // 앞으로는 game.spawnUnitDirect 직접 호출 대신 이걸로 통과시키면 됨
        game.spawnUnitDirect(key, x, game.groundY, team);
        this.markDirty();
    }
};

window.onload = () => game.init();
