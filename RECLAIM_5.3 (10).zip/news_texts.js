// news_texts.js - Centralized news text presets
(function () {
    'use strict';

    window.NEWS_TEXTS = {
        cityArmor: {
            lockLocation: true,
            location: '수도권 외곽 순환도로 상공 | 17:45',
            title: '긴급속보',
            headline: '[속보] 원블루국 국군, 시가지 진입 개시 첫 교차로 확보',
            ticker: '수도권 상공 헬기 편대 진입... 긴장 고조   ///   군 당국 \"시민 안전 위해 작전 지역 접근 금지\"   ///   통신망 일부 장애 발생... 복구 작업 중   ///   야간 통행 금지령 검토 중'
        },
        cityMid: {
            lockLocation: true,
            location: '원블루국 도심 | 17:58',
            title: '긴급담화',
            headline: '원블루국 대통령',
            ticker: '원블루국 도심, 적 병력 대거 유입... 피해 급증   ///   적군 공세 강화... 외곽 방어선 곳곳에서 교전   ///   도심 진입로로 적 병력 유입 확인... 긴급 대피 권고   ///   사상자 증가... 구급 출동 지연, 의료 대응 한계'
        },
        cityTotalWar: {
            lockLocation: true,
            location: '도시 외곽 방어선 | 18:09',
            title: '긴급속보',
            headline: '붉은네모국 대통령 총력전 선포',
            ticker: '[속보] 전면 총력전 돌입 선언   ///   국방부 \"모든 예비전력 즉시 동원\"   ///   도심 통제 구역 확대   ///   시민 대피령 강화'
        }
    };
})();
